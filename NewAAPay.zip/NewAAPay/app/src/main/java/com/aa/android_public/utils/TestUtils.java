package com.aa.android_public.utils;

import android.content.Context;
import android.content.Intent;

import com.support.fastthink.utils.LogUtils;
import com.support.fastthink.utils.UniformString;

public class TestUtils {
    public static void setTestAlipay(Context context) {
        Intent broadCastIntent = new Intent();
        broadCastIntent.setAction(UniformString.ALIPAYSTART_ACTION);
        broadCastIntent.putExtra("type", "qrset");
        broadCastIntent.putExtra("mark", "PayTest");
        broadCastIntent.putExtra("money", "0.01");
        context.sendBroadcast(broadCastIntent);
        LogUtils.setConsoleLogger(context, "支付宝实时码生成测试：1");
    }

    public static void setTestWeChat(Context context) {
        Intent broadCastIntent = new Intent();
        broadCastIntent.setAction(UniformString.WECHATSTART_ACTION);
        broadCastIntent.putExtra("mark", "PayTest");
        broadCastIntent.putExtra("money", "0.01");
        context.sendBroadcast(broadCastIntent);
        LogUtils.setConsoleLogger(context, "微信实时码生成测试：1");
    }
}
