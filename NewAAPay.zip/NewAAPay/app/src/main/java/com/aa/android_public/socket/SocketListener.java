package com.aa.android_public.socket;

public interface SocketListener {
    public void onOpen();
    public void onClose();
    public void onError(Exception ex);


    public void getAlipayUUid(String keyid,String messageuuid);//服务端下发获取支付宝id
    public void getQrPayurl(String channle_type,String keyid,String messageuuid,String money,String mark);//服务端下发获取通道生成二维码
    public void onMessageToMain(String liushui,String bishu ,String xiane,String key_id);//后台下发通道信息
    public void onMessageToBlance(String blance);//后台下发码商的余额
    public void onCloseChannel(String keyid);//关闭通道

    public void onMessageError(String msg,boolean isShow);//通道错误信息
    public void onMessageGetWay(int alipay,int wechat);//通道网关信息

    public void onMainAlipayReceived(String mark,String userid,String money,String keyid);//服务端下发支付宝收款订单

    public void onMessageLoginError(String msg,boolean isShow);//通道错误信息

    public void onMessageIp(String msg);//ip信息
    public void onMessageIpError(String msg);//ip错误，弹框提示
}
