package com.aa.android_public.utils;

import android.content.Context;
import android.content.Intent;

import com.support.fastthink.utils.LogUtils;
import com.support.fastthink.utils.UniformString;

public class AlipayReceivedUtils {

    //跳转过去
    public static void sendAlipayBill(Context context,String mark,String userid,String money) {

        Intent broadCastIntent = new Intent();
        broadCastIntent.setAction(UniformString.ALIPAYSTART_ACTION);
        broadCastIntent.putExtra("type", UniformString.RECEIPTTYPE);
        broadCastIntent.putExtra("mark", mark);
        broadCastIntent.putExtra("userid", userid);
        broadCastIntent.putExtra("money", money);
        context.sendBroadcast(broadCastIntent);


        LogUtils.setConsoleLogger(context, "支付宝收款模式---1start"+mark+"    "+userid +"    "+money);



    }

}
