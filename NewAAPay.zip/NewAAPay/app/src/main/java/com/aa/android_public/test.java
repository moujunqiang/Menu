package com.aa.android_public;


import static com.support.fastthink.data.StringUtils.getDoubleValue;

public class test {
    public static void main(String[] args)  {
        String test="(剩余: ¥784.54)";
        String test1=test.substring(test.indexOf("¥")+1, test.indexOf(")"));

        float d = getDoubleValue(test1);
        System.out.println(d>784.54);
    }
}
