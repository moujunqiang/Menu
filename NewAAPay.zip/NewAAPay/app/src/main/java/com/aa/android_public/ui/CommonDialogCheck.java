package com.aa.android_public.ui;

import android.app.Dialog;
import android.content.Context;
import android.content.res.ColorStateList;
import android.content.res.Resources;
import android.os.Handler;
import android.os.Message;
import android.text.TextUtils;
import android.view.View;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.aa.android_public.activity.MainToolSokcetUtils;
import com.aa.android_public.utils.CheckUserIdUtils;
import com.support.fastthink.R;
import com.support.fastthink.utils.Utils;

public class CommonDialogCheck<E> extends Dialog {

    private View view;
    private onButtonCLickListener buttonCLickListener;

    public interface onButtonCLickListener {
        void onActivityButtonClick(int position);
    }

    private TextView alipayVersion;
    private TextView alipayActivity;
    private TextView wechatVersion;
    private TextView wechatActivity;
    private TextView checkHoutai;
    private RelativeLayout checkHoutaiIng;
    private TextView textbuttonContent;

    boolean isStartConnect = false;
    boolean isNeedAlipay = false;
    boolean isOkAlipay = false;
    boolean isNeedWechat = false;
    boolean isOkWechat = false;

    MainToolSokcetUtils mainToolSokcetUtils;
    ColorStateList gray;
    ColorStateList black;

    //确认与取消弹框
    public CommonDialogCheck(Context context,  final onButtonCLickListener listener
            , MainToolSokcetUtils mainToolSokcetUtils) {
        super(context, R.style.common_dialog);
        this.mainToolSokcetUtils=mainToolSokcetUtils;
        view = View.inflate(context, R.layout.dialog_check, null);
        getWindow().setBackgroundDrawableResource(android.R.color.transparent);
        setContentView(view);
        setCancelable(false);        //设置点击对话框以外的区域时，是否结束对话框
        this.buttonCLickListener = listener;
         textbuttonContent = (TextView) view.findViewById(R.id.tv_login_submit);
        ImageView ivClose = view.findViewById(R.id.iv_close);
        ivClose.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                dismiss();
            }
        });
        textbuttonContent.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //确定
                dismiss();
                buttonCLickListener.onActivityButtonClick(1);
            }
        });
        textbuttonContent.setEnabled(false);


        alipayVersion = (TextView) view.findViewById(R.id.check_num1_alipay_version);
        alipayActivity = (TextView) view.findViewById(R.id.check_num1_alipay_activity);
        wechatVersion = (TextView) view.findViewById(R.id.check_num2_wechat_version);
        wechatActivity = (TextView) view.findViewById(R.id.check_num2_wechat_activity);
        checkHoutai = (TextView) view.findViewById(R.id.check_num3_houtai);
        checkHoutaiIng = (RelativeLayout) view.findViewById(R.id.check_num3_houtaiing);

        //颜色
        Resources resource = (Resources) getContext().getResources();
        gray = (ColorStateList) resource.getColorStateList(R.color.slategray);
        black = (ColorStateList) resource.getColorStateList(R.color.colorPrimary);


    }

    public  void setData(String aliPayKey, String weChatKey){
        textbuttonContent.setEnabled(false);
        //传递过来通道
        if (!TextUtils.isEmpty(aliPayKey)) {
            isNeedAlipay=true;
            String version = Utils.getVersionAlipay(getContext());
            if (version.equals("10.1.35.828")) {
                alipayVersion.setText("支付宝版本" + version );
                alipayVersion.setTextColor(black);
            } else {
                alipayVersion.setText("支付宝版本" + version );
                alipayVersion.setTextColor(gray);
            }
            boolean isrun = Utils.isAppRunning(getContext(), "com.eg.android.AlipayGphone");
            if (isrun) {
                alipayActivity.setText("支付宝已打开" );
                alipayActivity.setTextColor(black);
            } else {
                alipayActivity.setText("支付宝未打开" );
                alipayActivity.setTextColor(gray);
            }
            if(version.equals("10.1.35.828")&&isrun){
                isOkAlipay=true;
            }else{
                isOkAlipay=false;
            }
        } else {
            isNeedAlipay=false;
            alipayVersion.setText("支付宝版本  不需检测");
            alipayActivity.setText("支付宝活跃  不需检测");
            alipayVersion.setTextColor(gray);
            alipayActivity.setTextColor(gray);
        }
        if (!TextUtils.isEmpty(weChatKey)) {
            isNeedWechat=true;
            String version = Utils.getVersionWechat(getContext());
            if (version.equals("7.0.3")) {
                wechatVersion.setText("微信版本" + version );
                wechatVersion.setTextColor(black);
            } else {
                wechatVersion.setText("微信版本" + version);
                wechatVersion.setTextColor(gray);
            }
            boolean isrun = Utils.isAppRunning(getContext(), "com.tencent.mm");
            if (isrun) {
                wechatActivity.setText("微信已打开");
                wechatActivity.setTextColor(black);
            } else {
                wechatActivity.setText("微信未打开");
                wechatActivity.setTextColor(gray);
            }
            if(version.equals("7.0.3")&&isrun){
                isOkWechat=true;
            }else{
                isOkWechat=false;
            }
        } else {
            isNeedWechat=false;
            wechatVersion.setText("微信版本  不需检测");
            wechatActivity.setText("微信活跃  不需检测");
            wechatVersion.setTextColor(gray);
            wechatActivity.setTextColor(gray);
        }


        //判断是否检测后台，开始检测，和结束检测
        //看是否符合条件启动socket
        if (isNeedAlipay == true && isNeedWechat == true) {
            if (isOkAlipay && isOkWechat) {
                //启动
                isStartConnect = true;
            } else {
                //不启动
                isStartConnect = false;
            }
        } else if (isNeedAlipay == true && isNeedWechat == false) {
            if (isOkAlipay) {
                //启动
                isStartConnect = true;
            } else {
                //不启动
                isStartConnect = false;
            }
        } else if (isNeedAlipay == false && isNeedWechat == true) {
            if (isOkWechat) {
                //启动
                isStartConnect = true;
            } else {
                //不启动
                isStartConnect = false;
            }
        } else {
            //不需要启动socket
            isStartConnect = false;
        }
        System.out.println("是否需要启动"+isStartConnect);

        if (isStartConnect == true) {
////            //查询UserId
//            CheckUserIdUtils.getAlipayUserId(getContext(),"" + (int) (Math.random() * 1000000));
            //启动
//            检测socket,while循环,检测到状态ok，设置可以点击启动
            checkHoutai.setTextColor(black);
            startCheckSocket();
        } else {
            //不启动
            checkHoutai.setTextColor(gray);
        }
    }

    public void startCheckSocket(){
        mainToolSokcetUtils.connectSocket();
        checkHoutaiIng.setVisibility(View.VISIBLE);
        new Thread(new Runnable() {
            @Override
            public void run() {
                connect();
            }
        }).start();
    }

    public void connect() {
        try {
            boolean isContinue=true;
            boolean isOpen=false;
            int times = 0;
            while (isContinue) {
                if(mainToolSokcetUtils.isOpen()){
                    //已经打开
                    isOpen=true;
                    isContinue=false;
                    System.out.println("当前socket通道检测中" + 0);
                }else{
                    if(mainToolSokcetUtils.getState()==1){
                        //已经打开
                        isOpen=true;
                        isContinue=false;
                        System.out.println("当前socket通道检测中" + 1);
                    }else if(mainToolSokcetUtils.getState()==2){
                        //已经关闭
                        isOpen=false;
                        isContinue=false;
                        System.out.println("当前socket通道检测中" + 2);
                    }
                  //其他情况算未响应，不处理
                }
                times++;
                Thread.sleep(1000);
                if(times>10){
                    isContinue=false;
                    isOpen=false;
                    System.out.println("当前socket通道检测中" + 3);
                }
            }
            System.out.println("当前socket通道检测完成" + isOpen);

            //通过hanlder刷新界面
            if(isOpen){
                Message msg = new Message();
                msg.what = 1;
                handler.sendMessage(msg);
            }else{
                Message msg = new Message();
                msg.what = 2;
                handler.sendMessage(msg);
            }

        } catch (Exception e) {
            System.out.print("当前socket通道检测错误：" + e.toString());
            e.printStackTrace();

        }
    }

    private  Handler handler = new Handler() {
        @Override
        public void handleMessage(Message msg) {
            if (msg.what == 1) {
                //打开
                textbuttonContent.setEnabled(true);
                checkHoutaiIng.setVisibility(View.GONE);
                checkHoutai.setText("后台通讯可连接");
                checkHoutai.setTextColor(black);
            }else  if (msg.what == 2) {
                //关闭
                textbuttonContent.setEnabled(false);
                checkHoutaiIng.setVisibility(View.GONE);
                checkHoutai.setText("后台通讯无法连接");
                checkHoutai.setTextColor(gray);
            }
            super.handleMessage(msg);
        }

    };
}
