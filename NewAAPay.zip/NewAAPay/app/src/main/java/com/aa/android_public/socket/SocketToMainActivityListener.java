package com.aa.android_public.socket;

public interface SocketToMainActivityListener {
   //余额，流水，订单，限额等
   public void onMessageToMain(String liushui,String bishu ,String xiane,String key_id);
   public void onMessageToBlance(String blance);//后台下发码商的余额
   public void onCloseChannel(String keyid);//关闭通道

   public void onMessageError(String msg,boolean isShow);//通道错误信息
   public void onMessageGetWay(int alipay,int wechat);//通道网关信息

   public void onMessageIp(String msg);//ip信息
   public void onMessageIpError(String msg);//ip错误，弹框提示
}
