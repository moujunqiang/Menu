package com.aa.android_public.utils;

import android.content.Context;
import android.view.View;
import android.widget.TextView;

import com.aa.android_public.R;
import com.support.fastthink.BaseAdapter;
import com.support.fastthink.entity.BalanceBean;

import java.util.List;

public class BalanceAdapter extends BaseAdapter<BalanceBean.DataBean> {
    private Context context;

    public BalanceAdapter(Context context) {
        super(context);
        this.context = context;
    }

    @Override
    public int getContentView() {
        return R.layout.item_balance;
    }


    @Override
    public void onInitView(View view, final int position) {
        List<BalanceBean.DataBean> balanceBeanList = getList();
        final BalanceBean.DataBean balanceBean = balanceBeanList.get(position);
        TextView tvName = get(view, R.id.tv_balance_name);
        TextView tvTime = get(view, R.id.tv_balance_time);
        TextView tvAmount = get(view, R.id.tv_balance_amount);

        tvTime.setText(balanceBean.getCreate_time());

        //1 充值（增加）2 扣除 (减少) 3 盘口用户支付消耗（减少）
        if (balanceBean.getType().equals("1")) {
            tvAmount.setText("+" + balanceBean.getMoney());
            tvName.setText("充值");
        } else if (balanceBean.getType().equals("2")) {
            tvAmount.setText("-" + balanceBean.getMoney());
            tvName.setText("扣除");
        } else if (balanceBean.getType().equals("3")) {
            tvAmount.setText("-" + balanceBean.getMoney());
            tvName.setText("用户支付消耗");
        } else {
            tvAmount.setText(balanceBean.getMoney());
            tvName.setText("未知类型");
        }
    }
}
