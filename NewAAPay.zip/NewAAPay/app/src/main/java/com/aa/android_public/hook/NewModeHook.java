package com.aa.android_public.hook;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.text.TextUtils;
import android.util.Base64;
import android.util.Log;

import com.aa.android_public.utils.Tools;
import com.alibaba.fastjson.JSON;
import com.support.fastthink.utils.LogUtils;
import com.support.fastthink.utils.UniformString;

import org.json.JSONArray;
import org.json.JSONObject;

import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Set;
import java.util.Vector;

import de.robv.android.xposed.XC_MethodHook;
import de.robv.android.xposed.XC_MethodReplacement;
import de.robv.android.xposed.XposedBridge;
import de.robv.android.xposed.XposedHelpers;

public class NewModeHook {

    public static ClassLoader mClassLoader;

    Handler handler = new Handler() {
        @Override
        public void handleMessage(Message msg) {
//            final String userid = (String) msg.obj;
//            new Thread(new Runnable() {
//                @Override
//                public void run() {
//                    delectContact(userid);
//                }
//            }).start();

        }
    };

    public void hookNewMode(final ClassLoader classLoader, final Context context) {
        mClassLoader = classLoader;
        LogUtils.sendLogger("支付宝红包消息开始");
        System.out.println("支付宝红包消息开始");
        try {
            //消息
//            Class<?> chatCallback = XposedHelpers.findClass("com.alipay.mobile.socialchatsdk.chat.data.ChatDataSyncCallback", classLoader);
            Class<?> chatCallback = XposedHelpers.findClass("com.alipay.mobile.socialchatsdk.chat.data.ChatDataSyncCallback", classLoader);//35
//
//            Class<?> chatDao = XposedHelpers.findClass("com.alipay.mobile.socialcommonsdk.bizdata.chat.data.ChatMsgDaoOp", classLoader);
//            Class<?> chatObj = XposedHelpers.findClass("com.alipay.mobile.socialcommonsdk.bizdata.chat.model.ChatMsgObj", classLoader);
////            final Class<?> syncmsg = XposedHelpers.findClass("com.alipay.mobile.rome.longlinkservice.syncmodel.SyncMessage", classLoader);
            final Class<?> syncmsg = XposedHelpers.findClass("com.alipay.mobile.rome.longlinkservice.syncmodel.SyncMessage", classLoader);//35
//
//            final Class<?> msgFac = XposedHelpers.findClass("com.alipay.mobile.socialchatsdk.chat.sender.MessageFactory", classLoader);
//            final Class<?> sendMsg = XposedHelpers.findClass("com.alipay.mobile.socialchatsdk.chat.sender.request.BaseChatRequest", classLoader);
//            final Class<?> redEn = XposedHelpers.findClass("com.alipay.mobile.redenvelope.proguard.n.a", classLoader);
            final Class<?> chatP = XposedHelpers.findClass("com.alipay.mobile.chatapp.ui.PersonalChatMsgActivity_", classLoader);
//
//            final Class<?> chatB = XposedHelpers.findClass("com.alipay.mobile.chatapp.ui.ChatMsgBaseActivity", classLoader);
            final Class<?> snsCou = XposedHelpers.findClass("com.alipay.android.phone.discovery.envelope.get.SnsCouponDetailActivity", classLoader);
//            final Class<?> giftCrow = XposedHelpers.findClass("com.alipay.giftprod.biz.crowd.gw.result.GiftCrowdDetailResult", classLoader);
            final Class<?> wire = XposedHelpers.findClass("com.squareup.wire.Wire", classLoader);
            final Class<?> msgPModel = XposedHelpers.findClass("com.alipay.mobilechat.core.model.message.MessagePayloadModel", classLoader);
//            final Class<?> A = XposedHelpers.findClass("com.alipay.android.phone.discovery.envelope.ui.util.a", classLoader);
//            final Class<?> resvdetail = XposedHelpers.findClass("com.alipay.android.phone.discovery.envelope.received.ReceivedDetailActivity", classLoader);
            XposedHelpers.findAndHookMethod(chatP, "onCreate", Bundle.class, new XC_MethodHook() {
                @Override
                protected void afterHookedMethod(MethodHookParam param) throws Throwable {
                    super.afterHookedMethod(param);
                    Intent intent = ((Activity) param.thisObject).getIntent();
                    Bundle bundle = intent.getExtras();
                    Set<String> set = bundle.keySet();
                    for (String string : set) {
                        XposedBridge.log("key=" + string + "--value=" + bundle.get(string));
                    }

                }
            });

            XposedHelpers.findAndHookMethod(chatCallback, "onReceiveMessage", syncmsg,
                    new XC_MethodHook() {
                        @Override
                        protected void beforeHookedMethod(MethodHookParam param) throws Throwable {
                            super.afterHookedMethod(param);
                            Object object = param.args[0];
                            System.out.println("聊天消息0=" + object.toString());
                            JSONArray msgArr = new JSONArray(syncmsg.getField("msgData").get(object).toString());
                            JSONObject msg1 = msgArr.getJSONObject(0);
                            String pl = msg1.getString("pl");
                            Object wireIns = XposedHelpers.newInstance(wire, new ArrayList<Class>());
                            Object decode_pl = XposedHelpers.callMethod(wireIns, "parseFrom", Base64.decode(pl, 0), msgPModel);
                            String decode_pl_str = JSON.toJSONString(decode_pl);
                            com.alibaba.fastjson.JSONObject decode_pl_json = JSON.parseObject(decode_pl_str);
                            String biz_type = decode_pl_json.getString("biz_type");
                            String content = decode_pl_json.getJSONObject("template_data").getString("m");
                            final String userid = decode_pl_json.getString("from_u_id");
                            String link = decode_pl_json.getString("link") + "#";

                            LogUtils.sendLogger("进来消息，聊天信息：" + content + ">>>link=" + link + "fromuserid=" + userid);

                            System.out.println("聊天消息" + content + ">>>link=" + link + "fromuserid=" + userid);

                            if (userid != null) {
                                //g广播回去，存起来

                                Intent broadCastIntent = new Intent();
                                broadCastIntent.putExtra("uid", userid);

                                broadCastIntent.setAction(UniformString.ALIPAYUID_ACTION);
                                context.sendBroadcast(broadCastIntent);

                            }
                            /**
                             * 收款----当收到收款消息后10秒后删除好友
                             */
//                            if ("COLLET".equals(biz_type) && content != null && content.contains("向你支付")) {
//                                XposedBridge.log("删除好友" + userid);
//                                Message message = new Message();
//                                message.what = 1;
//                                message.obj = userid;
//                                handler.sendMessageDelayed(message, 10000);
//                                System.out.println("删除好友");
//                            }

                            //自动回复
                            if (biz_type.equals("MR-F-ACC")) {
                                if (content.contains("你已经添加了") && content.contains("，现在可以开始聊天了。")) {
                                    LogUtils.sendLogger("进来MR-F-ACC信息，已成为好友" + "fromuserid=" + userid);

                                    /**
                                     * 防止不付款没有把该好友删除，五分钟后再次自动删除好友，已删除忽略
                                     */
//                                    try {
//                                        Message message = new Message();
//                                        message.what = 1;
//                                        message.obj = userid;
//                                        handler.sendMessageDelayed(message, 300000);
//                                    } catch (Exception e) {
//                                        e.printStackTrace();
//                                    }
                                }
                            } else if (biz_type.equals("CHAT")) {
                                LogUtils.sendLogger("进来CHAT信息：" + content);

                                if (content.contains("a")) {
                                    LogUtils.sendLogger("接收到对方收款指令：" + content);
                                    String money = content.split("a")[0];
                                    String remark = content.split("a")[1];
                                    sendBillMsg(userid, money, remark);
                                    System.out.println("接收到对方收款指令");
                                }

                            } else if (biz_type.equals("GIFTSHARE")) {
                                LogUtils.sendLogger("进来GIFTSHARE信息：" + content);

//                                sendMsg(userid, "感谢您的充值！正在自动领取 >>>>>");


                                //已领取红包，10秒后删除好友
//                                Message message = new Message();
//                                message.what = 1;
//                                message.obj = userid;
//                                handler.sendMessageDelayed(message, 10000);
//                                LogUtils.sendLogger("删除好友：" + userid);

                            }


                            String MessageInfo = (String) XposedHelpers.callMethod(object, "toString");
                            System.out.println("信息：" + MessageInfo);

                            for (int i = 0; i < msgArr.length(); i++) {
                                JSONObject msgData = msgArr.getJSONObject(i);
                                String pl_1 = msgData.getString("pl");
                                Object wireIns_1 = XposedHelpers.newInstance(XposedHelpers.findClass("com.squareup.wire.Wire", classLoader), new ArrayList<Class>());
                                Object decode_pl_1 = XposedHelpers.callMethod(wireIns_1, "parseFrom", Base64.decode(pl_1, 0), XposedHelpers.findClass("com.alipay.mobilechat.core.model.message.MessagePayloadModel", classLoader));
                                String decode_pl_str_1 = JSON.toJSONString(decode_pl_1);
                                com.alibaba.fastjson.JSONObject decode_pl_json_1 = JSON.parseObject(decode_pl_str_1);
                                System.out.println("信息：1=" + "decode_pl_json==>" + decode_pl_json_1.toJSONString());
                                String biz_type_1 = decode_pl_json_1.getString("biz_type");
                                String client_msg_id_1 = decode_pl_json_1.getString("client_msg_id");
                                if ("TRANSFER".equals(biz_type_1)) {//转账
                                    if (client_msg_id_1.contains("STTRANSFER")) {
                                        System.out.println("该条消息过滤：decode_pl_json==>");
                                    } else {


                                        String read_1 = decode_pl_json_1.getString("read");
                                        String from_u_id_1 = decode_pl_json_1.getString("from_u_id");//发送人的uid
                                        String to_u_id_1 = decode_pl_json_1.getString("to_u_id");
                                        String link_1 = decode_pl_json_1.getString("link");//查账直接扫码这个链接
                                        String template_data_1 = decode_pl_json_1.getString("template_data");
                                        com.alibaba.fastjson.JSONObject jsonObject = JSON.parseObject(template_data_1);
                                        String m_1 = jsonObject.getString("m");//收款金额
                                        String mark_1 = jsonObject.getString("title");//收款备注
                                        //回调
                                        String tradeNo_1 = getTextCenter2(link_1, "tradeNO=", "");

                                        Intent broadCastIntent = new Intent();
                                        broadCastIntent.setAction(UniformString.ZHUANZHANG_UID);


                                        broadCastIntent.putExtra("bill_no", tradeNo_1);
                                        broadCastIntent.putExtra("bill_money", m_1);
                                        broadCastIntent.putExtra("bill_mark", mark_1);
                                        broadCastIntent.putExtra("from_u_id", from_u_id_1);
                                        broadCastIntent.putExtra("bill_type", "alipay");

                                        context.sendBroadcast(broadCastIntent);


                                    }
                                }
                            }
                        }
                    });

            //Accessibility
            XposedHelpers.findAndHookMethod(snsCou, "a", Context.class, new XC_MethodReplacement() {
                @Override
                protected Object replaceHookedMethod(MethodHookParam param) throws Throwable {
                    return false;
                }
            });
//
//
//            XposedHelpers.findAndHookMethod(Activity.class, "onCreate", Bundle.class, new XC_MethodHook() {
//                @Override
//                protected void afterHookedMethod(final MethodHookParam param1) throws Throwable {
//                    super.afterHookedMethod(param1);
//                    Log.e(">>>>>>>>>>test0:==998", ":load activity:" + param1.thisObject.getClass().getPackage() + "=======" + param1.thisObject.getClass().getSimpleName());
//
//
//                }
//            });
//
            XposedHelpers.findAndHookMethod("com.alipay.mobile.socialcommonsdk.bizdata.chat.data.ChatMsgDaoOp", classLoader, "saveMessages",
                    List.class, boolean.class, new XC_MethodHook() {
                        @Override
                        protected void beforeHookedMethod(MethodHookParam paramAnonymousMethodHookParam) throws Throwable {
                            LogUtils.setConsoleLogger(context, "支付宝红包消息1Hook开始");

                            System.out.println("红包消息开始-------");
                            super.beforeHookedMethod(paramAnonymousMethodHookParam);
                            List test = (List) paramAnonymousMethodHookParam.args[0];
                            int i = 0;
                            while (i < test.size()) {
                                Object localObject3 = test.get(i);
                                String str2 = (String) XposedHelpers.getObjectField(localObject3, "bizMemo");
                                Object localObject1 = XposedHelpers.getObjectField(localObject3, "bizRemind");
                                Object localObject2 = XposedHelpers.getObjectField(localObject3, "bizType");
                                String str3 = (String) XposedHelpers.getObjectField(localObject3, "clientMsgId");
                                String str1 = (String) XposedHelpers.getObjectField(localObject3, "link");
                                String str4 = (String) XposedHelpers.getObjectField(localObject3, "mSenderUserId");
                                long l1 = XposedHelpers.getLongField(localObject3, "msgId");
                                String str5 = (String) XposedHelpers.getObjectField(localObject3, "msgOptType");
                                String str6 = (String) XposedHelpers.getObjectField(localObject3, "templateCode");
                                String str7 = (String) XposedHelpers.getObjectField(localObject3, "templateData");
                                long l2 = XposedHelpers.getLongField(localObject3, "localId");
                                localObject3 = new StringBuilder("消息-->bizMemo:");
                                ((StringBuilder) localObject3).append(str2);
                                ((StringBuilder) localObject3).append(" bizRemind");
                                ((StringBuilder) localObject3).append((String) localObject1);
                                ((StringBuilder) localObject3).append(" bizType:");
                                ((StringBuilder) localObject3).append((String) localObject2);
                                ((StringBuilder) localObject3).append(" clientMsgId:");
                                ((StringBuilder) localObject3).append(str3);
                                ((StringBuilder) localObject3).append(" link:");
                                ((StringBuilder) localObject3).append(str1);
                                ((StringBuilder) localObject3).append(" mSenderUserId:");
                                ((StringBuilder) localObject3).append(str4);
                                ((StringBuilder) localObject3).append(" msgId:");
                                ((StringBuilder) localObject3).append(l1);
                                ((StringBuilder) localObject3).append(" msgOptType:");
                                ((StringBuilder) localObject3).append(str5);
                                ((StringBuilder) localObject3).append(" tempCode:");
                                ((StringBuilder) localObject3).append(str6);
                                ((StringBuilder) localObject3).append(" tempData:");
                                ((StringBuilder) localObject3).append(str7);
                                ((StringBuilder) localObject3).append(" localId");
                                ((StringBuilder) localObject3).append(l2);
                                LogUtils.setConsoleLogger(context, "支付宝红包消息2Hook开始" + str1 + "    " + str2);
                                if (!TextUtils.isEmpty(str1)) {
                                    int m = str1.indexOf("&sign=");
                                    int k = str1.indexOf("&", str1.indexOf("&sign=") + 1);
                                    int j = k;
                                    if (k == -1) {
                                        j = str1.length();
                                    }
                                    str2 = str1.substring(m + 6, j);
                                    str1 = str1.substring(str1.indexOf("&crowdNo=") + 9, str1.indexOf("&", str1.indexOf("&crowdNo=") + 1));
                                    localObject1 = XposedHelpers.callMethod(XposedHelpers.callStaticMethod(XposedHelpers.findClass("com.alipay.mobile.framework.AlipayApplication", classLoader), "getInstance", new Object[0]), "getMicroApplicationContext", new Object[0]);
                                    localObject1 = XposedHelpers.callMethod(XposedHelpers.callMethod(XposedHelpers.callStaticMethod(XposedHelpers.findClass("com.alipay.mobile.common.helper.UserInfoHelper", classLoader), "getInstance", new Object[0]), "getUserInfo", new Object[]{localObject1}), "getUserId", new Object[0]);
                                    localObject2 = new StringBuilder("Sign=");
                                    ((StringBuilder) localObject2).append(str2);
                                    ((StringBuilder) localObject2).append(" crowdNo=");
                                    ((StringBuilder) localObject2).append(str1);

                                    LogUtils.setConsoleLogger(context, "支付宝红包消息3Hook开始" + localObject1 + "   ||||   " + localObject2);
                                    System.out.println("红包消息开始3");
                                    a(classLoader, str1, "1", str2, (String) localObject1, context);
                                }
                                i += 1;
                            }

                        }
                    });


        } catch (Error | Exception e) {
            LogUtils.setConsoleLogger(context, "红包异常：" + e.getMessage() + "");
        }
    }


    /**
     * 给用户发消息
     */
    public static void sendMsg(String userid, String content) {
        final Class<?> msgFac = XposedHelpers.findClass("com.alipay.mobile.socialchatsdk.chat.sender.MessageFactory", mClassLoader);

        XposedHelpers.callStaticMethod(msgFac, "createTextMsg", userid, "1", content, null, null, false);
    }


    /**
     * 自动领取红包
     */
    static void a(final ClassLoader classLoader, final String s, final String s2, final String s3, final String s4, final Context context) {


        final Object callMethod = XposedHelpers.callMethod(XposedHelpers.callStaticMethod(XposedHelpers.findClass("com.alipay.mobile.beehive.util.ServiceUtil", classLoader),
                "getServiceByInterface", new Object[]{XposedHelpers.findClass("com.alipay.mobile.framework.service.common.RpcService", classLoader)}),
                "getRpcProxy", new Object[]{XposedHelpers.findClass("com.alipay.giftprod.biz.crowd.gw.GiftCrowdReceiveService", classLoader)});
        final Object instance = XposedHelpers.newInstance(XposedHelpers.findClass("com.alipay.giftprod.biz.crowd.gw.request.GiftCrowdReceiveReq", classLoader), new Object[0]);
        XposedHelpers.setObjectField(instance, "crowdNo", (Object) s);
        XposedHelpers.setObjectField(instance, "prevBiz", (Object) "chat");
        XposedHelpers.setObjectField(instance, "groupId", (Object) null);
        XposedHelpers.setObjectField(instance, "receiverUserType", (Object) s2);
        XposedHelpers.setObjectField(instance, "sign", (Object) s3);
        XposedHelpers.setObjectField(instance, "clientMsgID", (Object) s3);
        XposedHelpers.setObjectField(instance, "receiverId", (Object) s4);
        final Runnable runnable = new Runnable() {

            @Override
            public final void run() {
                try {
                    Thread.sleep(1000L);
                } catch (InterruptedException ex) {
                    ex.printStackTrace();
                }
                try {
                    XposedHelpers.callMethod(callMethod, "queryCrowd", new Object[]{instance});
                    final Object callMethod1 = XposedHelpers.callMethod(callMethod, "receiveCrowd", new Object[]{instance});
                    if (!"1000".equals(XposedHelpers.getObjectField(callMethod1, "resultCode"))) {
                        return;
                    }
                    final Object objectField = XposedHelpers.getObjectField(callMethod1, "giftCrowdInfo");
                    final Object objectField1 = XposedHelpers.getObjectField(callMethod1, "giftCrowdFlowInfo");



                    String mNo = (String) XposedHelpers.getObjectField(objectField, "crowdNo");
                    String alipayuserid = (String) XposedHelpers.getObjectField(XposedHelpers.getObjectField(objectField, "creator"), "userId");
                    String mRemark = (String) XposedHelpers.getObjectField(objectField, "remark");
                    String mMoney1 = (String) XposedHelpers.getObjectField(objectField1, "receiveAmount");

                    LogUtils.sendLogger("自动领取红包" + objectField.toString()+"   "+alipayuserid);

                    LogUtils.setConsoleLogger(context, "支付宝红包模式到账： 订单号：" + mNo + "金额：" + mMoney1 + " 备注:" + mRemark + " "+alipayuserid);

                    Intent broadCastIntent = new Intent();
                    broadCastIntent.putExtra("no", mNo);
                    broadCastIntent.putExtra("userids", alipayuserid);
                    broadCastIntent.putExtra("money", mMoney1);
                    broadCastIntent.putExtra("remark", mRemark);
                    broadCastIntent.setAction(UniformString.REDENVELOPE_ACTION);
                    context.sendBroadcast(broadCastIntent);


                } catch (Exception ex2) {
                    ex2.printStackTrace();
                    LogUtils.setConsoleLogger(context, "领红包异常：" + ex2.getMessage() + "");
                }
            }
        };
        try {
            AsyncTask.THREAD_POOL_EXECUTOR.execute(runnable);
        } catch (Exception ex) {
            new StringBuilder("\u5ef6\u65f6\u9886\u53d6\u7ea2\u5305\u9519\u8bef\uff1a").append(ex);
            ex.printStackTrace();
        }
    }


    /**
     * 删除好友
     */
    public static void delectContact(String userid) {
        Object contactAccount = Tools.getContactAccount(mClassLoader, userid);

        Object handleRelationReq = XposedHelpers.newInstance(XposedHelpers.findClass("com.alipay.mobilerelation.biz.shared.req.HandleRelationReq", mClassLoader));
        String userId = XposedHelpers.getObjectField(contactAccount, "userId") + "";
        String account = XposedHelpers.getObjectField(contactAccount, "account") + "";
        XposedHelpers.setObjectField(handleRelationReq, "targetUserId", userId);
        XposedHelpers.setObjectField(handleRelationReq, "alipayAccount", account);
        XposedHelpers.setObjectField(handleRelationReq, "bizType", "2");
        Object service = Tools.getRpcService(Tools.getAlipayApplication(mClassLoader));
        LogUtils.sendLogger("红包删除好友service结果" + service.toString());

        Object alipayRelationManageService = XposedHelpers.callMethod(service, "getRpcProxy", XposedHelpers.findClass("com.alipay.mobilerelation.biz.shared.rpc.AlipayRelationManageService", mClassLoader));
        Object re = XposedHelpers.callMethod(alipayRelationManageService, "handleRelation", handleRelationReq);

        LogUtils.sendLogger("红包删除好友:+" + userId + "+结果" + JSON.toJSONString(re));

    }

    public static void deleteAll(final Context context) {
        final ClassLoader classLoader = context.getClassLoader();
        final Object callMethod = XposedHelpers.callMethod(XposedHelpers.callStaticMethod(XposedHelpers.findClass("com.alipay.mobile.framework.AlipayApplication", classLoader), "getInstance", new Object[0]), "getMicroApplicationContext", new Object[0]);
        final List list = (List) XposedHelpers.callMethod(XposedHelpers.callMethod(callMethod, "findServiceByInterface", new Object[]{"com.alipay.mobile.personalbase.service.SocialSdkContactService"}), "getAllFriends", new Object[0]);
        if (list == null || list.size() == 0) {
            LogUtils.setConsoleCollection(context, "未找到好友，停止删除好友");

            return;
        }
        final Object callMethod2 = XposedHelpers.callMethod(XposedHelpers.callMethod(callMethod, "findServiceByInterface", new Object[]{"com.alipay.mobile.framework.service.common.RpcService"}), "getRpcProxy", new Object[]{XposedHelpers.findClass("com.alipay.mobilerelation.biz.shared.rpc.AlipayRelationManageService", classLoader)});
        LogUtils.setConsoleCollection(context, "开始删除" + list.size() + "个好友");
        for (final Object next : list) {
            if (new Date().getTime() - XposedHelpers.getLongField(next, "version") > 600000L) {
                final String s = (String) XposedHelpers.getObjectField(next, "userId");
                final Object instance = XposedHelpers.newInstance(XposedHelpers.findClass("com.alipay.mobilerelation.biz.shared.req.HandleRelationReq", classLoader), new Object[0]);
                XposedHelpers.setObjectField(instance, "targetUserId", (Object) s);
                XposedHelpers.setObjectField(instance, "bizType", (Object) "2");
                new Thread(new Runnable() {
                    @Override
                    public void run() {
                        XposedHelpers.callMethod(callMethod2, "handleRelation", new Object[]{instance});
                    }
                }).start();
            }
        }
        LogUtils.setConsoleCollection(context, "删除好友完成");

    }

//    private void a(Context paramContext)
//    {
//        ClassLoader localClassLoader = paramContext.getClassLoader();
//        final Object localObject1 = XposedHelpers.callMethod(XposedHelpers.callStaticMethod(XposedHelpers.findClass("com.alipay.mobile.framework.AlipayApplication", localClassLoader), "getInstance", new Object[0]), "getMicroApplicationContext", new Object[0]);
//        Object localObject2 = (List)XposedHelpers.callMethod(XposedHelpers.callMethod(localObject1, "findServiceByInterface", new Object[] { "com.alipay.mobile.personalbase.service.SocialSdkContactService" }), "getAllFriends", new Object[0]);
//        if ((localObject2 == null) || (((List)localObject2).size() == 0))
//        {
//            LogUtils.setConsoleCollection(paramContext, "未找到好友，停止删除好友");
//
//            return;
//        }
//        localObject1 = XposedHelpers.callMethod(XposedHelpers.callMethod(localObject1, "findServiceByInterface", new Object[] { "com.alipay.mobile.framework.service.common.RpcService" }), "getRpcProxy", new Object[] { XposedHelpers.findClass("com.alipay.mobilerelation.biz.shared.rpc.AlipayRelationManageService", localClassLoader) });
//        d.a(paramContext, "开始删除" + ((List)localObject2).size() + "个好友");
//        localObject2 = ((List)localObject2).iterator();
//        while (((Iterator)localObject2).hasNext())
//        {
//            Object localObject3 = ((Iterator)localObject2).next();
//            long l = XposedHelpers.getLongField(localObject3, "version");
//            if (new Date().getTime() - l > 600000L)
//            {
//                localObject3 = (String)XposedHelpers.getObjectField(localObject3, "userId");
//                final Object localObject4 = XposedHelpers.newInstance(XposedHelpers.findClass("com.alipay.mobilerelation.biz.shared.req.HandleRelationReq", localClassLoader), new Object[0]);
//                XposedHelpers.setObjectField(localObject4, "targetUserId", localObject3);
//                XposedHelpers.setObjectField(localObject4, "bizType", "2");
//                new Thread(new Runnable()
//                {
//                    public void run()
//                    {
//                        XposedHelpers.callMethod(localObject1, "handleRelation", new Object[] { localObject4 });
//                    }
//                }).start();
//            }
//        }
//        d.a(paramContext, "删除好友完成");
//    }


    /**
     * 收款----给用户发送收款订单
     */
    public static String sendBillMsg(String userid, String money, String remark) {
        LogUtils.sendLogger("进入支付宝生成收款订单=" + userid + "   " + money + "   " + remark);

        Class appclazz = XposedHelpers.findClass("com.alipay.mobile.framework.AlipayApplication", mClassLoader);
        Object mapp2 = XposedHelpers.callStaticMethod(appclazz, "getInstance");
        Object bundleContext = XposedHelpers.callMethod(mapp2, "getBundleContext");
        ClassLoader classload = (ClassLoader) XposedHelpers.callMethod(bundleContext, "findClassLoaderByBundleName", "android-phone-wallet-socialpayee");
        Object service = Tools.getRpcService(Tools.getAlipayApplication(mClassLoader));

        XposedBridge.log("service " + service);

        Object SingleCollectRpc = XposedHelpers.callMethod(service, "getRpcProxy", XposedHelpers.findClass("com.alipay.android.phone.personalapp.socialpayee.rpc.SingleCollectRpc", classload));
        Object contactAccount = Tools.getContactAccount(classload, userid);
        String name = XposedHelpers.getObjectField(contactAccount, "name") + "";
        String userId = XposedHelpers.getObjectField(contactAccount, "userId") + "";
        String logonId = XposedHelpers.getObjectField(contactAccount, "account") + "";
        Object singleCreateReq = XposedHelpers.newInstance(XposedHelpers.findClass("com.alipay.android.phone.personalapp.socialpayee.rpc.req.SingleCreateReq", classload));
        XposedBridge.log(" singleCreateReq " + JSON.toJSONString(singleCreateReq));
        Field[] fields = singleCreateReq.getClass().getDeclaredFields();
        for (Field field : fields) {
            XposedBridge.log(" " + field.getName() + " " + field.getType());

        }

        XposedHelpers.setObjectField(singleCreateReq, "userName", name);
        XposedHelpers.setObjectField(singleCreateReq, "userId", userId);
        XposedHelpers.setObjectField(singleCreateReq, "logonId", logonId);
        XposedHelpers.setObjectField(singleCreateReq, "desc", remark);
        XposedHelpers.setObjectField(singleCreateReq, "payAmount", money);
        XposedHelpers.setObjectField(singleCreateReq, "billName", "个人收款");
        XposedHelpers.setObjectField(singleCreateReq, "source", "chat");

        Object o = XposedHelpers.callMethod(SingleCollectRpc, "createBill", singleCreateReq);
        LogUtils.sendLogger("进入支付宝生成收款订单5=" + userid + "   " + money + "   " + remark + "    结果=" + JSON.toJSONString(o));
        return JSON.toJSONString(o);
    }

    public static String getTextCenter2(String text, String begin, String end) {
        try {
            int b = text.indexOf(begin) + begin.length();
            int e = text.length();
            return text.substring(b, e);
        } catch (Exception e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
            return "error";
        }
    }

}