package com.aa.android_public.utils;

import android.content.Context;
import android.content.Intent;

import com.support.fastthink.utils.LogUtils;
import com.support.fastthink.utils.UniformString;

public class CheckUserIdUtils {
    //跳转过去查UserId
    public static void getAlipayUserId(Context context,String messageuuid) {
        Intent broadCastIntent = new Intent();
        broadCastIntent.setAction(UniformString.ALIPAYSTART_ACTION);
        broadCastIntent.putExtra("type", "solidcode");
        broadCastIntent.putExtra("isrun", "runing");
        broadCastIntent.putExtra("messageuuid", messageuuid);
        context.sendBroadcast(broadCastIntent);
        LogUtils.setConsoleLogger(context, "支付宝查询UserId---1start");
    }
}
