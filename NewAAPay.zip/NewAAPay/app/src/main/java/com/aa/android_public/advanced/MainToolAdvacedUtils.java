package com.aa.android_public.advanced;

import android.content.Context;
import android.os.Handler;
import android.text.TextUtils;
import android.util.Log;

import com.aa.android_public.utils.CheckBalanceUtils;
import com.support.fastthink.BaseApplication;
import com.support.fastthink.BaseParam;
import com.support.fastthink.utils.SPUtils;
import com.support.fastthink.utils.UniformString;

import static com.aa.android_public.advanced.TransferUtils.getAlipayTransferOrder;

//处理定时心跳，定时保活，定时查询状态等定时状态工具
public class MainToolAdvacedUtils {
    private Context context;

    public MainToolAdvacedUtils(Context context) {
        this.context = context;
    }

    //高级功能，启动转账模式
    public void startAdvace() {
        //先判断当前转账的模式，是定时还是限额触发，如果是定时，启动定时，如果是限额，重置内部额度
        int tempType = SPUtils.getInstance().getInt(BaseParam.TRANSFERMODETYPE,0);
        if(tempType==1){
            //限额启动,重置收款
            BaseParam.nowBlanceAlipay=0;
        }else if(tempType==2){
            //定时转，启动定时
            int temptime=   SPUtils.getInstance().getInt(BaseParam.TRANSFERTIME,30*60*1000);
            if(temptime==-1){

            }else{
                handlerActive.postDelayed(runnableActive, temptime);//
            }

        }

    }
    //移除定时脚本
    public void stopAdvace() {
        //先判断当前转账的模式，是定时还是限额触发，如果是定时，启动定时，如果是限额，重置内部额度
        BaseParam.nowBlanceAlipay=0;
        handlerActive.removeCallbacks(runnableActive);//
    }

    ////////定时转支付宝固定额度////////
    Handler handlerActive = new Handler();
    Runnable runnableActive = new Runnable() {
        @Override
        public void run() {
            Log.i(UniformString.UNIFIEDPRINTING, "当前定时支付宝转账");
            //支付宝/微信
            //先获取额度，周期，然后
            getAlipayTransferOrder(context,"" + (int) (Math.random() * 1000000)+"");
            //60秒一个周期
            int temptime=   SPUtils.getInstance().getInt(BaseParam.TRANSFERTIME,30*60*1000);
            if(temptime==-1){

            }else{
                String pw = SPUtils.getInstance().getString(BaseParam.TRANSFERPW);
                if(!TextUtils.isEmpty(pw)&&BaseParam.isStartAdvaced&& BaseApplication.isStart){
                    handlerActive.postDelayed(this, temptime*60*1000);
                }

            }

        }
    };


}
