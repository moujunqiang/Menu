package com.aa.android_public.broadcast;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

import com.aa.android_public.activity.MainToolSokcetUtils;
import com.aa.android_public.hook.NewModeHook;
import com.aa.android_public.utils.SocketSendUtils;
import com.support.fastthink.BaseParam;
import com.support.fastthink.utils.LogUtils;
import com.support.fastthink.utils.SPUtils;
import com.support.fastthink.utils.UniformString;

import org.json.JSONException;
import org.json.JSONObject;

public class NewModeReceived extends BroadcastReceiver {

    @Override
    public void onReceive(final Context context, Intent intent) {
        LogUtils.sendLogger("支付宝收款模式Activity");
        if(intent.getStringExtra("type").equals(UniformString.DELETEALIPAYUID)){
//            final String userid = intent.getStringExtra("uid");
            System.out.println("开始删除支付宝好友");
            new Thread(new Runnable() {
                @Override
                public void run() {

                    try {
//                        NewModeHook.delectContact(userid);
                        NewModeHook.deleteAll(context);
                    } catch (Exception e) {
                        e.printStackTrace();

                    }


                }
            }).start();
        }else  if (intent.getStringExtra("type").equals(UniformString.RECEIPTTYPE)) {

            final String userid = intent.getStringExtra("userid");
            final String money = intent.getStringExtra("money");
            final String remark = intent.getStringExtra("mark");

            LogUtils.sendLogger("支付宝收款4当前通道的指令" + "mark:" + remark + "  user_id:" + userid + "  money：" + money);

            new Thread(new Runnable() {
                @Override
                public void run() {
                    LogUtils.sendLogger("支付宝收款4.5当前通道的指令" + "mark:" + remark + "  user_id:" + userid + "  money：" + money);

                    try {
                        final String sendBillMsg = NewModeHook.sendBillMsg(userid, money, remark);
                        JSONObject jsonObj = null;

                        jsonObj = new JSONObject(sendBillMsg);
                        boolean result = jsonObj.optBoolean("success", false);
                        if (result) {
                            String alipayNo = jsonObj.optString("transferNo", "");

                            //发送广播回去，然后发送socket
                            LogUtils.sendLogger("支付宝收款5当前通道的指令" + "mark:" + remark + "  user_id:" + userid + "  money：" + money + "  alipayNo" + alipayNo);

                            LogUtils.setConsoleCollection(context,"发送创建支付宝收款订单成功1:\n 支付宝订单号：" + alipayNo + "\n 金额:" + money + "\n 备注:" + remark+"\n userid:" + userid);


                            Intent broadCastIntent = new Intent();
                            broadCastIntent.putExtra("order_type", "success");
                            broadCastIntent.putExtra("mark", remark);
                            broadCastIntent.putExtra("userid", userid);
                            broadCastIntent.putExtra("money", money);
                            broadCastIntent.putExtra("message","" );
                            broadCastIntent.putExtra("alipayNo", alipayNo);
                            broadCastIntent.setAction(UniformString.RECEIPT_ORDER);
                            context.sendBroadcast(broadCastIntent);
                        } else {
                            LogUtils.setConsoleCollection(context,"发送创建支付宝收款订单失败1:\n 支付宝失败信息：" + jsonObj.toString() + "\n 金额:" + money + "\n 备注:" + remark+"\n userid:" + userid);


                            LogUtils.setConsoleLogger(context,"获取支付宝收款订单失败");
                            Intent broadCastIntent = new Intent();
                            broadCastIntent.putExtra("order_type", "error");
                            broadCastIntent.putExtra("mark", remark);
                            broadCastIntent.putExtra("userid", userid);
                            broadCastIntent.putExtra("money", money);
                            broadCastIntent.putExtra("message", jsonObj.toString()+"" );
                            broadCastIntent.putExtra("alipayNo", "");
                            broadCastIntent.setAction(UniformString.RECEIPT_ORDER);
                            context.sendBroadcast(broadCastIntent);
                        }
                    } catch (Exception e) {
                        e.printStackTrace();
                        LogUtils.setConsoleCollection(context,"发送创建支付宝收款订单异常1:\n 支付宝失败信息：" + e.getMessage() + "\n 金额:" + money + "\n 备注:" + remark+"\n userid:" + userid);


                        LogUtils.setConsoleLogger(context,"获取支付宝收款订单异常："+e.getMessage());
                        Intent broadCastIntent = new Intent();
                        broadCastIntent.putExtra("order_type", "error");
                        broadCastIntent.putExtra("mark", remark);
                        broadCastIntent.putExtra("userid", userid);
                        broadCastIntent.putExtra("money", money);
                        broadCastIntent.putExtra("message",  e.getMessage()+"");
                        broadCastIntent.putExtra("alipayNo", "");
                        broadCastIntent.setAction(UniformString.RECEIPT_ORDER);
                        context.sendBroadcast(broadCastIntent);
                    }


                }
            }).start();
        }
    }
}
