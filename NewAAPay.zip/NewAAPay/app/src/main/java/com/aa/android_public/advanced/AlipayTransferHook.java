package com.aa.android_public.advanced;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.util.Log;
import android.view.KeyEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import java.lang.reflect.Field;
import java.util.Date;

import de.robv.android.xposed.XC_MethodHook;
import de.robv.android.xposed.XposedBridge;
import de.robv.android.xposed.XposedHelpers;

import static com.support.fastthink.data.StringUtils.getDoubleValue;
import static com.support.fastthink.utils.UniformString.ALIPAY_BACK_TRANFER;
import static com.support.fastthink.utils.UniformString.ALIPAY_BACK_TRANFER1;
import static com.support.fastthink.utils.UniformString.ALIPAY_TRANFER;

/**
 * 高级功能---支付宝转账Hook
 */
public class AlipayTransferHook {

    public static String transferType = "";

    public static boolean transferMoneyType = false;//固定金额，true，全部

    public static String transferAccount = "";
    public static String transferPw = "";
    public static String transferAmount = "";
    public static String transferRemark = "";

    public static String transferName = "";
    public static String transferCard = "";
    private boolean isRegistered = false;
    private boolean isRegisteredWanchegn = false;
    public static boolean isDownTranfer = false;//不是转账中。true代表转账中

    public static BlanceBean blanceBean = new BlanceBean();

    static long lastTimetemp = 0;

    static boolean isNowisOne = false;//密码盘是否是第二个页面


    public static int nowActivity = 1;//1是支付宝，2是银行卡，转账进来看当前是多少

    public AlipayTransferHook() {
        isRegistered = false;
        isRegisteredWanchegn = false;
        isDownTranfer = false;

    }

    static String nowParam1 = "";

    static Context Allcontext;
    public void hookActivityTransfer(final ClassLoader classLoader, final Context context) {
        try {
            XposedHelpers.findAndHookMethod(Activity.class, "onCreate", Bundle.class, new XC_MethodHook() {
                @Override
                protected void afterHookedMethod(final MethodHookParam param1) throws Throwable {
                    super.afterHookedMethod(param1);
                    nowParam1 = param1.thisObject.getClass().getSimpleName();
                    Log.e(">>>>>>>>>>test0:==998", ":load activity:" + param1.thisObject.getClass().getPackage() + "=======" + param1.thisObject.getClass().getSimpleName());

                    if (isRegistered == false) {
                        isRegistered = true;
                        Allcontext=context;
                        setRegistered(classLoader, context);
                    }
                }
            });
        } catch (Error | Exception e) {
            Log.e("test临时", "hookTFAccount error:" + e.getMessage());
        }
    }

    public void setRegistered(final ClassLoader classLoader, final Context context) {
//        com.alipay.mobile.chatapp.ui=======PersonalChatMsgActivity_
        XposedHelpers.findAndHookMethod("com.alipay.mobile.chatapp.ui.PersonalChatMsgActivity_", classLoader, "onCreate", Bundle.class, new XC_MethodHook() {
            @Override
            protected void afterHookedMethod(MethodHookParam param) throws Throwable {
                Intent broadCastIntent = new Intent();
                System.out.println("跳转回主页1");
                broadCastIntent.setAction(ALIPAY_BACK_TRANFER);
                context.sendBroadcast(broadCastIntent);
            }
        });

        //第一步，输入账户界面
        XposedHelpers.findAndHookMethod("com.alipay.mobile.transferapp.ui.TFToAccountInputActivity_", classLoader, "onCreate", Bundle.class, new XC_MethodHook() {
            @Override
            protected void afterHookedMethod(MethodHookParam param) throws Throwable {
                methodHookParamAlipay1 = param;
                if (isDownTranfer) {
                    Field jinErField = XposedHelpers.findField(param.thisObject.getClass(), "b");
                    final Object jinErView = jinErField.get(param.thisObject);
                    XposedHelpers.callMethod(jinErView, "setText", transferAccount);

                    Field test = XposedHelpers.findField(param.thisObject.getClass(), "d");
                    Button tostButton4 = (Button) test.get(param.thisObject);
                    tostButton4.performClick();
                }

            }
        });

        XposedHelpers.findAndHookMethod("com.alipay.mobile.transferapp.ui.TFToAccountConfirmActivity_", classLoader, "onCreate", Bundle.class, new XC_MethodHook() {
            @Override
            protected void afterHookedMethod(MethodHookParam paramAnonymous2MethodHookParam) throws Throwable {
                methodHookParamAlipay2 = paramAnonymous2MethodHookParam;
                try {
                    if (isDownTranfer) {
                        nowActivity = 1;
                        Field jinErField0 = XposedHelpers.findField(paramAnonymous2MethodHookParam.thisObject.getClass(), "f");
                        final Object jinErView0 = jinErField0.get(paramAnonymous2MethodHookParam.thisObject);
                        object1 = XposedHelpers.callMethod(jinErView0, "getEditText");
                        XposedHelpers.callMethod(object1, "setText", transferAmount);

                        Field jinErField1 = XposedHelpers.findField(paramAnonymous2MethodHookParam.thisObject.getClass(), "g");
                        final Object jinErView1 = jinErField1.get(paramAnonymous2MethodHookParam.thisObject);
                        XposedHelpers.callMethod(jinErView1, "setText", transferRemark);

                        Field test = XposedHelpers.findField(paramAnonymous2MethodHookParam.thisObject.getClass(), "h");
                        tostButton7 = (Button) test.get(paramAnonymous2MethodHookParam.thisObject);
                        tostButton7.performClick();
                    }

                } catch (Exception e) {
                    e.printStackTrace();
                }


            }
        });


        //密码 弹框，所有都在这个容器里,com.alipay.android.msp.ui.views.MspContainerActivity
        XposedHelpers.findAndHookMethod("com.alipay.android.msp.ui.views.MspContainerActivity", classLoader, "onCreate", Bundle.class, new XC_MethodHook() {
            @Override
            protected void afterHookedMethod(final MethodHookParam param) throws Throwable {
                methodHookParam = param;

                if (isRegisteredWanchegn == false) {
                    isRegisteredWanchegn = true;
//                if(true){

                    //转账密码盘第一阶段：查询到立即付款按钮，并点击，
                    XposedHelpers.findAndHookMethod(TextView.class, "setText", CharSequence.class, TextView.BufferType.class, boolean.class, int.class, new XC_MethodHook() {
                        @Override
                        protected void afterHookedMethod(MethodHookParam paramAnonymous2MethodHookParam) {
                            try {
                                final TextView localTextView = (TextView) paramAnonymous2MethodHookParam.thisObject;
                                Class localClass = XposedHelpers.findClass("com.flybird.FBBorderText", classLoader);
                                Class localClass1 = XposedHelpers.findClass("android.widget.TextView", classLoader);

                                if (paramAnonymous2MethodHookParam.thisObject.getClass().getName().equals(localClass.getName())) {

                                    if (localTextView.getText().toString().trim().equals("立即付款")) {
                                        textViewEnterNext = localTextView;
                                    }

//
//                                //先查询余额，然后拿到余额，判断是转固定，还是转全部，
                                }

                                if (paramAnonymous2MethodHookParam.thisObject.getClass().getName().equals(localClass.getName())) {
                                    System.out.println("进入账户余额0进入3。0=" + localTextView.getText().toString().trim() + paramAnonymous2MethodHookParam.thisObject.getClass().getSimpleName());

                                    if (localTextView.getText().toString().trim().equals("确认付款")) {
                                        isNowisOne = false;//不是第二个界面，
                                    } else if (localTextView.getText().toString().trim().equals("选择付款方式")) {
                                        isNowisOne = true;//打开了第二个界面
                                    }

                                    System.out.println(localTextView.getText().toString() + "进入账户余额0进入3。1=" + isNowisOne+"MspContainerActivity".equals(nowParam1));
                                    if ((localTextView.getText().toString().trim().equals("余额宝")
                                            || localTextView.getText().toString().trim().contains("储蓄卡")
                                            || localTextView.getText().toString().trim().contains("信用卡"))
                                            && "MspContainerActivity".equals(nowParam1)
                                            && isNowisOne == false) {
                                        long nowTimetemp = new Date().getTime();
                                        System.out.println(localTextView.getText().toString() + "进入账户余额0进入3。2=" + nowParam1);
                                        if (lastTimetemp == 0 || (nowTimetemp - lastTimetemp) > 5000) {
                                            System.out.println(localTextView.getText().toString() + "进入账户余额0进入3。3=" + nowParam1);
                                            lastTimetemp = new Date().getTime();
                                            ;
                                            //当进入这几个词条，说明余额不足，
                                            //1关闭转账得基础页面
                                            //1，关闭窗口，2，广播回去，并且提示失败



                                            //调用返回按钮关闭这个页面，并且关闭主要页面
                                            Message message = new Message();
                                            message.what = 4;
                                            message.obj = "";
                                            handler.sendMessageDelayed(message, 500);
                                        }

                                    }

//                                点击账户开始查询余额
                                }
                                if (paramAnonymous2MethodHookParam.thisObject.getClass().getName().equals(localClass.getName())) {

                                    if (localTextView.getText().toString().trim().equals("账户余额")) {
                                        System.out.println("进入账户余额1" + transferMoneyType);
                                        //如果是转固定金额，匹配到账户余额，直接点击立即付款
                                        if (transferMoneyType == false) {
                                            //转固定，有余额，直接转，
                                            localTextView.postDelayed(new Runnable() {
                                                public void run() {
                                                    ((ViewGroup) textViewEnterNext.getParent()).performClick();
                                                }
                                            }, 1000L);

                                        } else {
                                            //转全部，需要先差全部余额
                                            System.out.println("进入账户余额2" + transferMoneyType);
                                            //如果是第一次进来，需要点击查询，如果是第二次进来，之前已经查到了，不再点击
                                            if (blanceBean.getNowRemark().equals(transferRemark) && blanceBean.isGetBlance() &&
                                                    blanceBean.isNow()) {
                                                System.out.println("进入账户余额3" + transferMoneyType);
                                                //不再查询，直接立即付款
                                                localTextView.postDelayed(new Runnable() {
                                                    public void run() {
                                                        ((ViewGroup) textViewEnterNext.getParent()).performClick();
                                                    }
                                                }, 500L);
                                            } else {
                                                //需要先查询
                                                System.out.println("进入账户余额4" + transferMoneyType);
                                                localTextView.postDelayed(new Runnable() {
                                                    public void run() {
                                                        ((ViewGroup) localTextView.getParent()).performClick();
                                                    }
                                                }, 500L);
                                            }
                                        }

                                    }


//      查询余额
                                }
                                if (paramAnonymous2MethodHookParam.thisObject.getClass().getName().equals(localClass.getName())) {

                                    if (localTextView.getText().toString().trim().contains("(剩余: ¥") &&
                                            localTextView.getText().toString().trim().contains(")")) {

                                        String tempBlance = localTextView.getText().toString().trim();//"(剩余: ¥784.54)";
                                        String tempBlance1 = tempBlance.substring(tempBlance.indexOf("¥") + 1, tempBlance.indexOf(")"));
                                        float nowBlance = getDoubleValue(tempBlance1);
                                        System.out.println("进入账户余额5==" + nowBlance);
                                        //查询到余额，先点击返回，然后再关闭当前页面，再设置一便需要转的金额，
                                        blanceBean.setBlance(nowBlance);//余额是多少
                                        blanceBean.setGetBlance(true);//是否拿到余额
                                        blanceBean.setNowRemark(transferRemark);//这次查询的单号，备注，如果下次另一笔转账，还是要查询

                                        localTextView.postDelayed(new Runnable() {
                                            public void run() {
//                                        点击了返回后，再点关闭，再重新设置，再点击确定，立即付款，再走一次
                                                ((ViewGroup) localTextView.getParent().getParent().getParent()).performClick();
                                                //handler延迟一秒去 设置
                                                //延迟半秒，重新设置前面的值并且点确定按钮。。先查询是银行卡还是支付宝转账
//                                                TransferToCardFormActivity_，TFToAccountInputActivity_的对象去设置 下
                                                if (nowActivity == 1) {
                                                    //支付宝去设置金额，
                                                    Message message = new Message();
                                                    message.what = 1;
                                                    message.obj = "";
                                                    handler.sendMessageDelayed(message, 1000);
                                                } else {
                                                    //银行卡去设置金额，需要在返回关闭页面后，
                                                    Message message = new Message();
                                                    message.what = 2;
                                                    message.obj = "";
                                                    handler.sendMessageDelayed(message, 1000);
                                                }
                                                //调用返回按钮关闭这个页面
                                                Message message = new Message();
                                                message.what = 3;
                                                message.obj = "";
                                                handler.sendMessageDelayed(message, 500);


                                            }
                                        }, 500L);
                                    }

                                }


                                if (paramAnonymous2MethodHookParam.thisObject.getClass().getName().equals(localClass1.getName())) {


                                    if (localTextView.getText().toString().trim().equals("完成")) {
                                        System.out.println("点击完成333333333333333333333333");
                                        localTextView.postDelayed(new Runnable() {
                                            public void run() {
                                                localTextView.performClick();
                                                Intent broadCastIntent = new Intent();
                                                if (transferType.equals("transferCard")) {
                                                    broadCastIntent.putExtra("name", transferName);//名字
                                                    broadCastIntent.putExtra("card", transferCard);//银行卡
                                                } else {//(AliPayHook.transferType.equals("transfer")){
                                                    broadCastIntent.putExtra("account", transferAccount);//支付宝账号
                                                }

                                                broadCastIntent.putExtra("type", transferType);//转账支付宝/银行卡


                                                broadCastIntent.putExtra("pw", transferPw);//密码
                                                if(transferMoneyType==false){
                                                    //转固定
                                                    broadCastIntent.putExtra("amount", transferAmount);//金额

                                                }else{
                                                    //转全部
                                                    broadCastIntent.putExtra("amount", blanceBean.getBlance()+"");//金额
                                                }
                                                broadCastIntent.putExtra("remark", transferRemark);//备注，订单号
                                                broadCastIntent.setAction(ALIPAY_TRANFER);
                                                isDownTranfer = false;//转账完成
                                                context.sendBroadcast(broadCastIntent);
                                            }
                                        }, 500L);
                                    }
                                }
                            } catch (Exception e) {
                                e.printStackTrace();
                            }
                        }

                    });
                }
            }
        });

        //进入密码，判断是个人还是企业
        XposedHelpers.findAndHookMethod("com.alipay.android.app.safepaybase.widget.SafeInputWidget", classLoader, "b",
                String.class,
                new XC_MethodHook() {
                    @Override
                    protected void afterHookedMethod(MethodHookParam param) throws Throwable {
                        Field test = XposedHelpers.findField(param.thisObject.getClass(), "b");
                        EditText tostButton4 = (EditText) test.get(param.thisObject);
                        //个人，还是企业
                        if (tostButton4.getVisibility() == View.VISIBLE) {
                            //企业，
                            isQiyeAlipay = true;
                            Field qiyeB = XposedHelpers.findField(param.thisObject.getClass(), "b");
                            qiyeInputPw = (EditText) qiyeB.get(param.thisObject);

                            Field qiyeD = XposedHelpers.findField(param.thisObject.getClass(), "d");
                            qiyeInputEnter = (Button) qiyeD.get(param.thisObject);

                            qiyeInputEnter.postDelayed(new Runnable() {
                                public void run() {
                                    if (isDownTranfer) {
                                        qiyeInputPw.setText(transferPw);

                                        qiyeInputEnter.performClick();
                                    }
                                }
                            }, 500L);
                        } else {
                            isQiyeAlipay = false;
                            //个人
                        }


                    }
                });
        XposedHelpers.findAndHookMethod("com.alipay.android.app.safepaybase.widget.SimplePassword", classLoader, "initView", new XC_MethodHook() {
            @Override
            protected void afterHookedMethod(final MethodHookParam param) throws Throwable {

                Field test = XposedHelpers.findField(param.thisObject.getClass(), "mEditText");
                tostButton3 = (EditText) test.get(param.thisObject);

                tostButton3.postDelayed(new Runnable() {
                    public void run() {
                        if (isQiyeAlipay) {
                            //企业，啥也不干,上面会执行企业输入
                        } else {
                            //是个人界面，输入个人密码
                            if (isDownTranfer) {
                                System.out.println("个人密码输入");
                                tostButton3.setText(transferPw);
                            }
                        }

                    }
                }, 500L);

//                XposedHelpers.findAndHookMethod(TextView.class, "setText", CharSequence.class, TextView.BufferType.class, boolean.class, int.class, new XC_MethodHook() {
//                    @Override
//                    protected void afterHookedMethod(MethodHookParam paramAnonymous2MethodHookParam) {
//                        try {
//                            final TextView test = (TextView) paramAnonymous2MethodHookParam.thisObject;
//                            if (test.getText().toString().equals("重新输入")) {
//                                test.postDelayed(new Runnable() {
//                                    public void run() {
//                                        test.performClick();
//
//                                        tostButton3.postDelayed(new Runnable() {
//                                            public void run() {
//                                                if (isQiyeAlipay) {
//                                                    //企业重新输入密码
//                                                    qiyeInputPw.setText(transferPw);
//                                                    qiyeInputEnter.performClick();
//                                                } else {
//                                                    //个人重新输入密码
//                                                    tostButton3.setText(transferPw);
//                                                }
//
//                                            }
//                                        }, 500L);
//                                    }
//                                }, 500L);
//                            }
//
//                        } catch (Exception e) {
//                            e.printStackTrace();
//                        }
//                    }
//
//                });
            }
        });
        XposedHelpers.findAndHookMethod("com.alipay.mobile.transferapp.ui.TransferToCardFormActivity_", classLoader, "onCreate", Bundle.class, new XC_MethodHook() {
            @Override
            protected void afterHookedMethod(final MethodHookParam paramAnonymous2MethodHookParam) throws Throwable {
                try {
                    methodHookParamYinhangka1 = paramAnonymous2MethodHookParam;
                    if (isDownTranfer) {
                        nowActivity = 2;
                        Field jinErField1 = XposedHelpers.findField(paramAnonymous2MethodHookParam.thisObject.getClass(), "c");
                        final Object jinErView1 = jinErField1.get(paramAnonymous2MethodHookParam.thisObject);
                        Object jinErField3 = XposedHelpers.callMethod(jinErView1, "getEtContent");
                        XposedHelpers.callMethod(jinErField3, "setFocusable", true);
                        XposedHelpers.callMethod(jinErField3, "setFocusableInTouchMode", true);
                        XposedHelpers.callMethod(jinErView1, "setText", transferCard);

                        XposedHelpers.callMethod(paramAnonymous2MethodHookParam.thisObject, "a");


                        Field jinErField0 = XposedHelpers.findField(paramAnonymous2MethodHookParam.thisObject.getClass(), "d");
                        final Object jinErView0 = jinErField0.get(paramAnonymous2MethodHookParam.thisObject);
                        Object jinErField2 = XposedHelpers.callMethod(jinErView0, "getEtContent");
                        XposedHelpers.callMethod(jinErField2, "setFocusable", true);
                        XposedHelpers.callMethod(jinErField2, "setFocusableInTouchMode", true);
                        XposedHelpers.callMethod(jinErView0, "setText", transferName);

                        Field jinErField5 = XposedHelpers.findField(paramAnonymous2MethodHookParam.thisObject.getClass(), "e");
                        object2 = jinErField5.get(paramAnonymous2MethodHookParam.thisObject);
                        Object jinErField6 = XposedHelpers.callMethod(object2, "getEtContent");
                        XposedHelpers.callMethod(jinErField6, "setFocusable", true);
                        XposedHelpers.callMethod(jinErField6, "setFocusableInTouchMode", true);
                        XposedHelpers.callMethod(object2, "setText", transferAmount);


                        Field test = XposedHelpers.findField(paramAnonymous2MethodHookParam.thisObject.getClass(), "m");
                        tostButton5 = (Button) test.get(paramAnonymous2MethodHookParam.thisObject);

                        tostButton5.postDelayed(new Runnable() {
                            public void run() {
                                isFist = true;
                                tostButton5.performClick();
                            }
                        }, 500L);
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                }


            }
        });
        XposedHelpers.findAndHookMethod("com.alipay.mobile.transferapp.ui.TFToCardConfirmActivity_", classLoader, "onCreate", Bundle.class, new XC_MethodHook() {
            @Override
            protected void afterHookedMethod(MethodHookParam paramAnonymous2MethodHookParam) throws Throwable {
                try {
                    if (isFist == true) {
                        isFist = false;
                        //finish
                        XposedHelpers.callMethod(paramAnonymous2MethodHookParam.thisObject, "finish", new Object[0]);
                        tostButton5.performClick();
                    } else {

                        if (isDownTranfer) {

                            Field jinErField0 = XposedHelpers.findField(paramAnonymous2MethodHookParam.thisObject.getClass(), "g");
                            final Object jinErView0 = jinErField0.get(paramAnonymous2MethodHookParam.thisObject);
                            XposedHelpers.callMethod(jinErView0, "setText", transferRemark);


                            Field test = XposedHelpers.findField(paramAnonymous2MethodHookParam.thisObject.getClass(), "h");
                            tostButton6 = (Button) test.get(paramAnonymous2MethodHookParam.thisObject);
//                    tostButton5.performClick();
                            tostButton6.postDelayed(new Runnable() {
                                public void run() {
                                    tostButton6.performClick();
                                }
                            }, 500L);

                        }

                    }

                } catch (Exception e) {
                    e.printStackTrace();
                }


            }
        });
//
//
//        //提现得弹框，当弹出继续提现得时候，继续
        Class<?> insertTradeMessageInfo = XposedHelpers.findClass("com.alipay.wealth.common.ui.PopupFloatView", classLoader);
        XposedBridge.hookAllMethods(insertTradeMessageInfo, "setConfirmBtn", new XC_MethodHook() {
            @Override
            protected void beforeHookedMethod(MethodHookParam param) throws Throwable {
                try {

                    //获取全部字段
                    Object object = param.args[0];
                    String MessageInfo = (String) XposedHelpers.callMethod(object, "toString");

                    System.out.println("提示语：" + MessageInfo);


                    Field quRenField = XposedHelpers.findField(param.thisObject.getClass(), "m");
                    tostButton = (Button) quRenField.get(param.thisObject);


                    if (MessageInfo != null) {
                        if (MessageInfo.equals("继续转账")) {
                            tostButton.postDelayed(new Runnable() {
                                public void run() {
                                    tostButton.performClick();
                                }
                            }, 500L);
                        }
                    }

                } catch (Exception e) {
                    System.out.println("弹框点击失败");

                }
                super.beforeHookedMethod(param);
            }
        });
    }

    static boolean isFist = false;
    //------------------------------------延迟点击------------------------------------------
    static boolean isQiyeAlipay = false;//区分企业还是个人转账
    static Button tostButton;//继续转账按钮
    static EditText tostButton3;//个人输入密码
    static EditText qiyeInputPw;//企业输入密码
    static Button qiyeInputEnter;//企业输入确认
    static Button tostButton5;//转银行卡下一步
    static Button tostButton6;//转银行卡下一步第二步

    static Button tostButton7;//转支付宝填写金额后确定，下一步

    static Object object1;//支付宝设置金额
    static Object object2;//银行卡设置金额

    static TextView textViewEnterNext;//立即付款的按钮

    static XC_MethodHook.MethodHookParam methodHookParam;//密码页面得主页

    static XC_MethodHook.MethodHookParam methodHookParamAlipay1;//转支付宝账号输入界面
    static XC_MethodHook.MethodHookParam methodHookParamAlipay2;//转支付宝账号输入金额主页

    static XC_MethodHook.MethodHookParam methodHookParamYinhangka1;//转银行卡得主页

    public static Handler handler = new Handler() {

        @Override
        public void handleMessage(Message msg) {
            System.out.println("进入账户余额" + "重新 设置金额下一步");
            try {
                if (msg.what == 1) {
                    blanceBean.setNow(true);
                    //支付宝设置金额，点击
                    XposedHelpers.callMethod(object1, "setText", blanceBean.getBlance() + "");
                    tostButton7.performClick();
                } else if (msg.what == 2) {
                    blanceBean.setNow(true);
                    //银行卡设置金额，点击
                    XposedHelpers.callMethod(object2, "setText", blanceBean.getBlance() + "");
                    isFist = true;
                    tostButton5.performClick();
                } else if (msg.what == 3) {
//                XposedHelpers.findClass("android.view.KeyEvent.", classLoader);
//                onKeyDown(KeyEvent.KEYCODE_BACK, null);
                    if (methodHookParam != null) {
                        XposedHelpers.callMethod(methodHookParam.thisObject, "onKeyDown", 4, null);
                    }
                } else if (msg.what == 4) {
                    if(isNowisOne==true){
                        //啥也不干
                        System.out.println("进入账户余额0进入3。4=啥也不干");

                    }else{
                        if (methodHookParam != null) {
                            System.out.println("进入账户余额----1");
                            XposedHelpers.callMethod(methodHookParam.thisObject, "onKeyDown", 4, null);
                            if (nowActivity == 1) {
                                System.out.println("进入账户余额----2");
                                XposedHelpers.callMethod(methodHookParamAlipay2.thisObject, "finish", new Object[0]);
                                XposedHelpers.callMethod(methodHookParamAlipay1.thisObject, "finish", new Object[0]);
                            } else {
                                System.out.println("进入账户余额----3");
                                XposedHelpers.callMethod(methodHookParamYinhangka1.thisObject, "finish", new Object[0]);
                            }
                        }
                        Intent broadCastIntent = new Intent();
                        broadCastIntent.setAction(ALIPAY_BACK_TRANFER1);//返回应用主页
                        isDownTranfer = false;//转账完成
                        Allcontext.sendBroadcast(broadCastIntent);
                    }


                }
            } catch (Exception e) {
                e.printStackTrace();
            }
            super.handleMessage(msg);
        }

    };

}
