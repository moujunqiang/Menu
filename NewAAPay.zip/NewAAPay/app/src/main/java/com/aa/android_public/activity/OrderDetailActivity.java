package com.aa.android_public.activity;


import android.os.Bundle;
import android.support.annotation.Nullable;
import android.view.View;
import android.widget.ListView;

import com.aa.android_public.R;
import com.aa.android_public.utils.OrderDetailAdapter;
import com.support.fastthink.BaseActivity;
import com.support.fastthink.entity.OrderBean;
import com.support.fastthink.ui.CommonDialog;
import com.support.fastthink.utils.DBManager;

import java.util.List;

public class OrderDetailActivity extends BaseActivity {
    private OrderDetailAdapter adapter;
    private ListView listView;


    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_order_detail);
        adapter = new OrderDetailAdapter(this);
        initView();
    }

    private void initView() {
        //返回
        this.findViewById(R.id.tv_home_back).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                finish();
            }
        });

        //清除前期数据库数据
        this.findViewById(R.id.tv_order_clear).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                new CommonDialog(OrderDetailActivity.this, "是否删除当前本地订单记录？", new CommonDialog.onButtonCLickListener() {
                    @Override
                    public void onActivityButtonClick(int position) {
                        if (position == 1) {
                            DBManager dbManager = new DBManager(OrderDetailActivity.this);
                            dbManager.deleteAll();
                            adapter.clear();
                            showToast("清除成功！");
                        }
                    }
                }).show();
            }
        });

        //列表
        listView = findViewById(R.id.lv_order_detail);
        listView.setAdapter(adapter);

        listView.setTranscriptMode(ListView.TRANSCRIPT_MODE_ALWAYS_SCROLL);
        listView.setStackFromBottom(true);


        //获取
        DBManager dbManager = new DBManager(this);
        List<OrderBean> orderBeanList = dbManager.findAllOrders();


        //加载
        if (orderBeanList != null && orderBeanList.size() > 0) {
            adapter.addWithClear(orderBeanList);
        }


    }
}
