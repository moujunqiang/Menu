package com.aa.android_public.activity;

import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.text.Editable;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.view.View;
import android.widget.AdapterView;
import android.widget.EditText;
import android.widget.TextView;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.aa.android_public.R;
import com.aa.android_public.utils.AccountAdapter;
import com.support.fastthink.BaseActivity;
import com.support.fastthink.BaseParam;
import com.support.fastthink.entity.AccountBean;
import com.support.fastthink.network.OkHttpManager;
import com.support.fastthink.network.Param;
import com.support.fastthink.network.PathConstant;
import com.support.fastthink.refresh.RefreshSwipeMenuListView;
import com.support.fastthink.ui.CommonDialog;
import com.support.fastthink.utils.LogUtils;
import com.support.fastthink.utils.SPUtils;
import com.support.fastthink.utils.UniformString;

import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * 账号列表
 */
public class AccountListActivity extends BaseActivity implements RefreshSwipeMenuListView.OnRefreshListener {
    private RefreshSwipeMenuListView lvAccountList;
    private TextView tvWechat, tvAlipay;
    private EditText etSearch;
    private AccountAdapter accountAdapter;
    private List<AccountBean.DataBean> accountBeanList = new ArrayList<>();
    private List<AccountBean.DataBean> accountBeanListTemp = new ArrayList<>();
    private List<AccountBean.DataBean> accountBeanListClick = new ArrayList<>();
    private String type = "";
    boolean onRefresh = false;
    private int refresh = 1;//页数

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_account_list);
        Intent intentType = getIntent();
        //获取类型1 支付宝 2微信
        type = intentType.getStringExtra("type");
        initView();
        getAccountList(refresh);
    }

    private void initView() {
        //微信展示
        tvWechat = findViewById(R.id.tv_wechat_account);
        //支付宝展示
        tvAlipay = findViewById(R.id.tv_alipay_account);
        //搜索输入框
        etSearch = findViewById(R.id.et_account_search);

        if (type.equals("2")) {
            //微信
            tvWechat.setVisibility(View.VISIBLE);
            tvAlipay.setVisibility(View.GONE);
        } else if (type.equals("1")) {
            //支付宝
            tvWechat.setVisibility(View.GONE);
            tvAlipay.setVisibility(View.VISIBLE);
        } else {
            tvWechat.setVisibility(View.GONE);
            tvAlipay.setVisibility(View.GONE);
        }

        //返回
        this.findViewById(R.id.tv_home_back).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                finish();
            }
        });

        //不配置
        this.findViewById(R.id.tv_account_submit).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (type.equals("1")) {
                    SPUtils.getInstance().put(BaseParam.NOWALIPAYMODE,-1);//置空
                    Intent intent = new Intent();
                    intent.putExtra("account", "");
                    setResult(UniformString.INTENTTALIPAY, intent);
                } else if (type.equals("2")) {
                    Intent intent = new Intent();
                    intent.putExtra("account", "");
                    setResult(UniformString.INTENTTWECHAT, intent);
                } else {
                    showToast("传入参数错误！");
                }
                finish();
            }
        });

        //搜索数据框
        etSearch.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {
                try {
                    if (!TextUtils.isEmpty(charSequence.toString())) {
                        searchAccount(charSequence.toString());
                    } else {
                        accountAdapter.addWithClear(accountBeanList);
                        accountBeanListTemp.clear();
                    }

                } catch (Exception e) {
                    e.printStackTrace();
                }
            }

            @Override
            public void afterTextChanged(Editable editable) {

            }
        });

        //列表
        accountAdapter = new AccountAdapter(this);

        lvAccountList = findViewById(R.id.lv_account_list);
        lvAccountList.setListViewMode(RefreshSwipeMenuListView.BOTH);
        lvAccountList.setAdapter(accountAdapter, RefreshSwipeMenuListView.BOTH);
        lvAccountList.setOnRefreshListener(this);


        //加载数据
        if (accountBeanList != null && accountBeanList.size() > 0) {
            accountAdapter.addWithClear(accountBeanList);
        }

        //点击行数据
        lvAccountList.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, final int i, long l) {

                LogUtils.sendLogger("当前点击" + i);
                if (accountBeanListTemp.size() > 0) {
                    accountBeanListClick = accountBeanListTemp;
                } else {
                    accountBeanListClick = accountBeanList;
                }

                if (i > 0) {
                    final int AlipayType=accountBeanListClick.get(i - 1).getChannel_id();
                    String alipay_type="";
                    if (AlipayType==1){
                        alipay_type="实时码";//实时码
                    }else if (AlipayType==3){
                        alipay_type="红包";//红包
                    }else if (AlipayType==5){
                        alipay_type="收款";//收款
                    }else if(AlipayType==6){
                        alipay_type="转账码";//转账码
                    }else {
                        alipay_type="微信";
                    }
                    new CommonDialog(AccountListActivity.this, "使用\"" + accountBeanListClick.get(i - 1).getName() + "\"进行\""+alipay_type+"\""+"模式", new CommonDialog.onButtonCLickListener() {
                        @Override
                        public void onActivityButtonClick(int position) {
                            if (position == 1) {
                                if (type.equals("1")) {

                                    String account = accountBeanListClick.get(i - 1).getReceipt_name();
                                    if (AlipayType==1){
                                        SPUtils.getInstance().put(BaseParam.NOWALIPAYMODE,1);//实时码
                                    }else if (AlipayType==3){
                                        SPUtils.getInstance().put(BaseParam.NOWALIPAYMODE,2);//红包
                                    }else if (AlipayType==5){
                                        SPUtils.getInstance().put(BaseParam.NOWALIPAYMODE,3);//收款
                                    }else if (AlipayType==6){
                                        SPUtils.getInstance().put(BaseParam.NOWALIPAYMODE,4);//转账码
                                    }
                                    Intent intent = new Intent();
                                    intent.putExtra("account", account);
                                    setResult(UniformString.INTENTTALIPAY, intent);
                                } else if (type.equals("2")) {
                                    String account = accountBeanListClick.get(i - 1).getReceipt_name();
                                    Intent intent = new Intent();
                                    intent.putExtra("account", account);
                                    setResult(UniformString.INTENTTWECHAT, intent);
                                } else {
                                    showToast("传入参数错误！");
                                }
                                finish();
                            }
                        }
                    }).show();
                }
            }
        });


    }

    //下拉刷新
    @Override
    public void onRefresh() {
        if (onRefresh == false) {
            onRefresh = true;
            refresh = 1;
            //下拉中，持续下拉不再刷新，停止后再刷新
            lvAccountList.postDelayed(new Runnable() {
                @Override
                public void run() {
                    onRefresh = false;
                    lvAccountList.complete();//listview停止刷新动画
                    getAccountList(refresh);
                    LogUtils.sendLogger("下拉刷新");
                }
            }, 1000);
        }

    }

    //上拉加载
    @Override
    public void onLoadMore() {
        refresh++;
        lvAccountList.postDelayed(new Runnable() {
            @Override
            public void run() {
                lvAccountList.complete();
                getAccountList(refresh);
                LogUtils.sendLogger("上拉加载  " + "页数：" + refresh + "   数量：" + accountBeanList.size());
            }
        }, 2000);
    }


    //搜索当前已加载的数据
    private void searchAccount(String content) {
        accountBeanListTemp.clear();
        Pattern pattern = Pattern.compile(content.replace("*", ""), Pattern.CASE_INSENSITIVE);

        for (int i = 0; i < accountBeanList.size(); i++) {
            Matcher matcher = pattern.matcher(accountBeanList.get(i).getName() + "");//名称
            if (matcher.find()) {
                accountBeanListTemp.add(accountBeanList.get(i));
            } else {
                Matcher matcher2 = pattern.matcher(accountBeanList.get(i).getReceipt_name());//Key
                if (matcher2.find()) {
                    accountBeanListTemp.add(accountBeanList.get(i));
                }
            }
        }

        accountAdapter.addWithClear(accountBeanListTemp);
    }


    /**
     * @param page//页数
     */
    public void getAccountList(int page) {

        List<Param> params = new ArrayList<Param>();
        params.add(new Param("merchant_id", SPUtils.getInstance().getInt(BaseParam.MERCHANTSID) + ""));
        params.add(new Param("type", type));
        params.add(new Param("page", page + ""));

        OkHttpManager.getInstance().post(params, PathConstant.URL_ACCOUNT, new OkHttpManager.HttpCallBack() {
            @Override
            public void onResponse(JSONObject jsonObject) {

                AccountBean bean = null;
                try {
                    bean = JSON.parseObject(jsonObject.toString(), AccountBean.class);
                } catch (Exception e) {
                    e.printStackTrace();
                }
                if (bean!=null&&bean.getCode() == 1) {
                    if (bean.getData() != null && bean.getData().size() > 0) {
                        if (refresh == 1) {
                            accountBeanList.clear();
                            accountBeanList.addAll(bean.getData());
                            accountAdapter.addWithClear(accountBeanList);
                        } else {
                            accountBeanList.addAll(bean.getData());
                            accountAdapter.addWithClear(accountBeanList);
                        }
                    }
                } else if (bean!=null&&bean.getCode() == 0) {
                    if (refresh == 1) {
                        showToast("暂无数据！");
                    } else {
                        showToast("已加载全部数据！");
                    }

                } else {
                    if (bean != null && bean.getMsg() != null) {
                        showDialog(bean.getMsg());
                    } else if (bean != null) {
                        showDialog(bean.getCode());
                    } else {
                        showDialog("获取账号列表失败！");
                    }
                }
            }

            @Override
            public void onFailure(String errorMsg) {
                showDialog(errorMsg);
            }
        });
    }
}
