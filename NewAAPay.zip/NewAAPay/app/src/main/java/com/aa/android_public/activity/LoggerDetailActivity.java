package com.aa.android_public.activity;

import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.text.method.ScrollingMovementMethod;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.widget.TextView;

import com.aa.android_public.R;
import com.support.fastthink.BaseActivity;

public class LoggerDetailActivity extends BaseActivity implements View.OnClickListener {
    //日志
    private TextView tvCollectionLog, tvProgramLog;
    private View viewCollectionLog, viewProgramLog;
    private TextView program, collection;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_logger);
        initView();
    }

    private void initView() {
        //收款日志
        tvCollectionLog = findViewById(R.id.tv_collection_log);
        tvCollectionLog.setOnClickListener(this);
        //收款日志横线
        viewCollectionLog = findViewById(R.id.view_collection_log);
        viewCollectionLog.setVisibility(View.VISIBLE);
        //程序日志
        tvProgramLog = findViewById(R.id.tv_program_log);
        tvProgramLog.setOnClickListener(this);
        //程序日志横线
        viewProgramLog = findViewById(R.id.view_program_log);
        viewProgramLog.setVisibility(View.GONE);

        Intent intent = getIntent();


        //程序日志
        program = findViewById(R.id.detail_console);
        program.setText(intent.getStringExtra("logger"));
        program.setMovementMethod(ScrollingMovementMethod.getInstance());
        program.setGravity(Gravity.BOTTOM);
        program.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                // TODO Auto-generated method stub
                if (event.getAction() == MotionEvent.ACTION_DOWN) {
                    //通知父控件不要干扰
                    v.getParent().requestDisallowInterceptTouchEvent(true);
                }
                if (event.getAction() == MotionEvent.ACTION_MOVE) {
                    //通知父控件不要干扰
                    v.getParent().requestDisallowInterceptTouchEvent(true);
                }
                if (event.getAction() == MotionEvent.ACTION_UP) {
                    v.getParent().requestDisallowInterceptTouchEvent(false);
                }
                return false;
            }
        });

        //订单日志
        collection = findViewById(R.id.detail_collection);
        collection.setText(intent.getStringExtra("logger2"));
        collection.setMovementMethod(ScrollingMovementMethod.getInstance());
        collection.setGravity(Gravity.BOTTOM);
        collection.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                // TODO Auto-generated method stub
                if (event.getAction() == MotionEvent.ACTION_DOWN) {
                    //通知父控件不要干扰
                    v.getParent().requestDisallowInterceptTouchEvent(true);
                }
                if (event.getAction() == MotionEvent.ACTION_MOVE) {
                    //通知父控件不要干扰
                    v.getParent().requestDisallowInterceptTouchEvent(true);
                }
                if (event.getAction() == MotionEvent.ACTION_UP) {
                    v.getParent().requestDisallowInterceptTouchEvent(false);
                }
                return false;
            }
        });

        collection.setVisibility(View.VISIBLE);
        program.setVisibility(View.GONE);

        this.findViewById(R.id.tv_home_back).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                finish();
            }
        });

    }

    @Override
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.tv_collection_log://订单日志
                viewCollectionLog.setVisibility(View.VISIBLE);
                viewProgramLog.setVisibility(View.GONE);
                collection.setVisibility(View.VISIBLE);
                program.setVisibility(View.GONE);
                break;
            case R.id.tv_program_log://程序日志
                viewCollectionLog.setVisibility(View.GONE);
                viewProgramLog.setVisibility(View.VISIBLE);
                collection.setVisibility(View.GONE);
                program.setVisibility(View.VISIBLE);
                break;
            default:
                break;
        }
    }

}
