package com.aa.android_public.broadcast;

public interface MainReceivedListener {
    public void reMessageUid(String uid);

}
