package com.aa.android_public.utils;

import android.content.Context;
import android.content.Intent;

import com.support.fastthink.utils.LogUtils;
import com.support.fastthink.utils.UniformString;

public class CheckBalanceUtils {
    //跳转过去到指定页面查询余额
    //22版本是先查询余额再转账，38版本合并，直接转账，转账输入密码前再核对是否余额足够
//    public static void getAlipayBalance(Context context, String remark) {
//        Intent broadCastIntent = new Intent();
//        broadCastIntent.setAction(UniformString.ALIPAYSTART_ACTION);
//        broadCastIntent.putExtra("type", "balance");
//        broadCastIntent.putExtra("isrun", "runing");
//        broadCastIntent.putExtra("remark", remark);
//        context.sendBroadcast(broadCastIntent);
//        LogUtils.setConsoleLogger(context, "余额查询---1");
//    }
}
