package com.aa.android_public.utils;

import android.content.Context;
import android.content.Intent;

import com.support.fastthink.utils.UniformString;

public class QrSetUtils {

    public static void getAlipaySetQr(Context context,  String money, String mark) {
        //跳转到支付宝实时码
        Intent broadCastIntent = new Intent();
        broadCastIntent.setAction(UniformString.ALIPAYSTART_ACTION);
        broadCastIntent.putExtra("type", "qrset");
        broadCastIntent.putExtra("mark", mark);
        broadCastIntent.putExtra("money", money);
        context.sendBroadcast(broadCastIntent);
    }

    public static void getWeChatSetQr(Context context, String money, String mark) {
        //跳转到微信实时码
        Intent broadCastIntent = new Intent();
        broadCastIntent.setAction(UniformString.WECHATSTART_ACTION);
        broadCastIntent.putExtra("type", "qrset");
        broadCastIntent.putExtra("mark", mark);
        broadCastIntent.putExtra("money", money);
        context.sendBroadcast(broadCastIntent);
    }
}
