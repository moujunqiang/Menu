package com.aa.android_public.broadcast;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;

import com.aa.android_public.hook.AlipayBalanceLiveIdHook;

import de.robv.android.xposed.XposedHelpers;

public class StartAlipayReceived extends BroadcastReceiver {
    @Override
    public void onReceive(Context context, Intent intent) {
        if (intent.getStringExtra("type").equals("qrset")) {
            //实时生成二维码
            Intent intent2 = new Intent(context, XposedHelpers.findClass("com.alipay.mobile.payee.ui.PayeeQRSetMoneyActivity", context.getClassLoader()));
            intent2.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            intent2.putExtra("mark", intent.getStringExtra("mark"));
            intent2.putExtra("money", intent.getStringExtra("money"));
            context.startActivity(intent2);
        } else if (intent.getStringExtra("type").equals("balance")) {
            //查余额，38版本合并，直接转账
//            AlipayBalanceLiveIdHook.type = "balance";
//            AlipayBalanceLiveIdHook.remark =intent.getStringExtra("remark");
////            Intent intent3 = new Intent(context, XposedHelpers.findClass("com.alipay.android.app.birdnest.ui.BNTplActivity", context.getClassLoader()));
////            intent3.putExtra("type", "balance");
////            intent3.putExtra("isrun", intent.getStringExtra("isrun"));
////            intent3.putExtra("remark", intent.getStringExtra("remark"));
////            intent3.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
////            context.startActivity(intent3);
//            context.startActivity(new Intent("android.intent.action.VIEW", Uri.parse("alipays://platformapi/startapp?appId=20000067&showTitleBar=YES&showToolBar=NO&url=alipays://platformapi/startapp?appId=20000019")));

        } else if (intent.getStringExtra("type").equals("solidcode")) {
            //固码-获取当前用户UserId
            Intent intent2 = new Intent(context, XposedHelpers.findClass("com.alipay.mobile.payee.ui.PayeeQRActivity", context.getClassLoader()));
            intent2.putExtra("isrun", intent.getStringExtra("isrun"));
            intent2.putExtra("messageuuid", intent.getStringExtra("messageuuid"));
            intent2.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            context.startActivity(intent2);
        } else if (intent.getStringExtra("type").equals("live")) {
            //保活
            Intent intent2 = new Intent(context, XposedHelpers.findClass("com.alipay.mobile.about.ui.AboutMainActivity_", context.getClassLoader()));
            intent2.putExtra("isrun", intent.getStringExtra("isrun"));
            intent2.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            context.startActivity(intent2);
        }

    }
}
