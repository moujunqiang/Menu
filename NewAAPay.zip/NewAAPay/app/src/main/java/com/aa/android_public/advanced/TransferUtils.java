package com.aa.android_public.advanced;

import android.content.Context;
import android.content.Intent;

import com.support.fastthink.utils.UniformString;

/**
 * 高级功能----转账跳转
 */
public class TransferUtils {
    //支付宝一个统一广播，收到后，去关闭网关，然后根据条件再调用下面的
    //跳转到AdvancedMainReceived接收
    public static  void getAlipayTransferOrder(Context context, String remark) {
        Intent broadCastIntent = new Intent();
        broadCastIntent.setAction(UniformString.ALIPAY_GET_TRANFER);
//        broadCastIntent.putExtra("balance", balance);
        broadCastIntent.putExtra("remark", remark);
        context.sendBroadcast(broadCastIntent);
    }

    //支付宝
    //跳转转账界面
    public static  void getAlipayTransfer(Context context, String account, String password, String amount, String remark,boolean isall) {
        Intent broadCastIntent = new Intent();
        broadCastIntent.setAction(UniformString.ALIPAYSTART_ACTION);
        broadCastIntent.putExtra("type", "transfer");
        broadCastIntent.putExtra("account", account);
        broadCastIntent.putExtra("pw", password);
        broadCastIntent.putExtra("amount", amount);
        broadCastIntent.putExtra("remark", remark);
        broadCastIntent.putExtra("isall", isall);
        context.sendBroadcast(broadCastIntent);
    }

    //支付宝
    //跳转转账银行卡界面
    public  static void getAlipayTransferCard(Context context, String name, String card, String password, String amount, String remark,boolean isall) {
        Intent broadCastIntent = new Intent();
        broadCastIntent.setAction(UniformString.ALIPAYSTART_ACTION);
        broadCastIntent.putExtra("type", "transferCard");
        broadCastIntent.putExtra("name", name);
        broadCastIntent.putExtra("card", card);
        broadCastIntent.putExtra("pw", password);
        broadCastIntent.putExtra("amount", amount);
        broadCastIntent.putExtra("isall", isall);
        broadCastIntent.putExtra("remark", remark);
        context.sendBroadcast(broadCastIntent);
    }
}
