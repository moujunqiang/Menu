package com.aa.android_public.utils;

import android.content.Context;
import android.content.Intent;

import com.support.fastthink.utils.LogUtils;
import com.support.fastthink.utils.UniformString;

public class AlipayWechatLiveUtils {

    //跳转过去关于页保活
    public static void getAlipayLive(Context context) {
        Intent broadCastIntent = new Intent();
        broadCastIntent.setAction(UniformString.ALIPAYSTART_ACTION);
        broadCastIntent.putExtra("type", "live");
        broadCastIntent.putExtra("isrun", "runing");
        context.sendBroadcast(broadCastIntent);
        LogUtils.setConsoleLogger(context, "支付宝保活---1start");
    }

    //跳转过去关于页保活
    public static void getWechatLive(Context context) {
        Intent broadCastIntent = new Intent();
        broadCastIntent.setAction(UniformString.WECHATSTART_ACTION);
        broadCastIntent.putExtra("type", "live");
        broadCastIntent.putExtra("isrun", "runing");
        context.sendBroadcast(broadCastIntent);
        LogUtils.setConsoleLogger(context, "微信保活---1start");
    }

}
