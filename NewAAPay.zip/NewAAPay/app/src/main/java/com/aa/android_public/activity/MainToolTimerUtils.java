package com.aa.android_public.activity;

import android.content.Context;
import android.os.Handler;
import android.util.Log;

import com.aa.android_public.utils.MainUtils;
import com.support.fastthink.BaseParam;
import com.support.fastthink.utils.UniformString;

//处理定时心跳，定时保活，定时查询状态等定时状态工具
public class MainToolTimerUtils {
    private Context context;
    public MainToolTimerUtils(Context context) {
        this.context = context;
    }

    //启动app活跃，socket检测定时脚本，
    public void startTimerHandler() {
        stopTimerHandler();
        handlerActive.postDelayed(runnableActive, 0);//启动支付宝微信活跃检测
        handlerSocket.postDelayed(runnableSocket,0);//启动socket活跃检测
        handlerSocketHeart.postDelayed(runnableSocketHeart,0);//定时发送socket心跳到后台
        handlerAlipayLive.postDelayed(runnableAlipayLive,60000);//定时发送支付宝广播保活
        handlerHttpHeart.postDelayed(runnableHttpHeart,5000);//定时发到后台
    }
    //移除定时脚本
    public void stopTimerHandler() {
        handlerActive.removeCallbacks(runnableActive);//移除支付宝微信活跃检测
        handlerSocket.removeCallbacks(runnableSocket);//移除socket活跃检测
        handlerSocketHeart.removeCallbacks(runnableSocketHeart);//移除定时发送socket心跳到后台
        handlerAlipayLive.removeCallbacks(runnableAlipayLive);//移除发送支付宝广播保活
        handlerHttpHeart.removeCallbacks(runnableHttpHeart);//移除http请求
    }

    ////////支付宝/微信活跃状态监控////////
    Handler handlerActive = new Handler();
    Runnable runnableActive = new Runnable() {
        @Override
        public void run() {
            Log.i(UniformString.UNIFIEDPRINTING, "当前定时查询APP活跃状态开始");
            //支付宝/微信
            MainUtils.setActive(context, UniformString.ACTIVEALL);
            //60秒一个周期
            handlerActive.postDelayed(this, 5000);
        }
    };

    ////////socket活跃状态监控////////
    Handler handlerSocket = new Handler();
    Runnable runnableSocket = new Runnable() {
        @Override
        public void run() {
            Log.i(UniformString.UNIFIEDPRINTING, "当前定时查询socket活跃状态开始");
            //socket查询
            MainUtils.setActive(context, UniformString.ACTIVESOCKET);
            //5秒一个周期
            handlerSocket.postDelayed(this, 5000);
        }
    };
    ////////socket定时发送心跳到后台////////
    Handler handlerSocketHeart = new Handler();
    Runnable runnableSocketHeart = new Runnable() {
        @Override
        public void run() {
            Log.i(UniformString.UNIFIEDPRINTING, "当前定时发送socket心跳开始");
            //socket心跳
            MainUtils.setActive(context, UniformString.ACTIVESOCKETHEART);
            //20秒一个周期
            handlerSocketHeart.postDelayed(this, 5000);
        }
    };
    //定时http到后台
    Handler handlerHttpHeart = new Handler();
    Runnable runnableHttpHeart = new Runnable() {
        @Override
        public void run() {
            Log.i(UniformString.UNIFIEDPRINTING, "当前定时发送http心跳开始");
            //socket心跳
            MainUtils.setActive(context, UniformString.ACTIVEHTTPHEART);
            //20秒一个周期
            handlerHttpHeart.postDelayed(this, 6000);
        }
    };

    ////////socket定时保活跳转////////
    Handler handlerAlipayLive = new Handler();
    Runnable runnableAlipayLive = new Runnable() {
        @Override
        public void run() {
            //如果支付宝配置了
            Log.i(UniformString.UNIFIEDPRINTING, "支付宝保活定时跳转开始");
            if(BaseParam.isOnresume){

            }else{
                //支付宝保活
                MainUtils.setActive(context, UniformString.ACTIVEALIPAYISRUN);
            }
            //60秒一个周期
            handlerAlipayLive.postDelayed(this, 30000);
        }
    };
}
