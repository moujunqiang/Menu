package com.support.fastthink.utils;

import android.annotation.SuppressLint;
import android.annotation.TargetApi;
import android.app.Activity;
import android.app.ActivityManager;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageInfo;
import android.database.Cursor;
import android.graphics.Color;
import android.os.Build;
import android.provider.Settings;
import android.support.annotation.NonNull;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;

import com.alibaba.fastjson.JSONObject;
import com.support.fastthink.entity.OrderBean;

import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

/**
 * 常用工具类
 */
public final class Utils {

    @SuppressLint("StaticFieldLeak")
    private static Context context;

    private Utils() {
        throw new UnsupportedOperationException("u can't instantiate me...");
    }

    /**
     * 初始化工具类
     *
     * @param context 上下文
     */
    public static void init(@NonNull final Context context) {
        Utils.context = context.getApplicationContext();
    }

    /**
     * 获取ApplicationContext
     *
     * @return ApplicationContext
     */
    public static Context getContext() {
        if (context != null) {
            return context;
        }
        throw new NullPointerException("should be initialized in application");
    }


    /**
     * 方法描述：判断某一应用是否正在运行
     *
     * @param context     上下文
     * @param packageName 应用的包名
     * @return true 表示正在运行，false表示没有运行
     */
    public static boolean isAppRunning(Context context, String packageName) {
        ActivityManager am = (ActivityManager) context.getSystemService(Context.ACTIVITY_SERVICE);
        List<ActivityManager.RunningTaskInfo> list = am.getRunningTasks(100);
        if (list.size() <= 0) {
            return false;
        }
        for (ActivityManager.RunningTaskInfo info : list) {
            if (info.baseActivity.getPackageName().equals(packageName)) {
                return true;
            }
        }
        return false;
    }


    /**
     * 启动一个app
     *
     * @param context
     * @param appPackageName
     */
    public static void startAPP(Context context, String appPackageName) {
        try {
            Intent intent = context.getPackageManager().getLaunchIntentForPackage(appPackageName);
            context.startActivity(intent);
        } catch (Exception e) {
        }
    }


    /**
     * 获取当前时间
     *
     * @return
     */
    public static String getCurrentDate() {
        long l = System.currentTimeMillis();
        Date date = new Date(l);
        SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
        String d = dateFormat.format(date);
        return d;
    }


    /**
     * 将时间戳转换为时间
     *
     * @param s
     * @return
     */
    public static String stampToDate(String s) {
        String res;
        SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        long lt = new Long(s);
        Date date = new Date(lt * 1000);
        res = simpleDateFormat.format(date);
        return res;
    }

    /**
     * 判断是否为浮点数
     *
     * @param str
     * @return
     */
    public static boolean isValidLong(String str) {
        try {
            //String a="132.456";
            float b = Float.parseFloat(str);
            return true;
        } catch (NumberFormatException e) {
            return false;
        }
    }

    /**
     * 判断是否为Json
     *
     * @param content
     * @return
     */
    public static boolean isJson(String content) {

        try {
            JSONObject jsonStr = JSONObject.parseObject(content);
            return true;
        } catch (Exception e) {
            return false;
        }
    }


    /**
     * @param tradeNo //订单号
     * @param type    //类型  1、支付宝(个人) 2、支付宝(商家) 3.微信
     * @param money   //金额
     * @param remark  //备注
     * @param status  //状态
     */
    public static void addOrder(String tradeNo, int type, String money, String remark, int status) {
        String dt = System.currentTimeMillis() + "";
        DBManager dbManager = new DBManager(Utils.getContext());
        dbManager.addOrder(new OrderBean(tradeNo, type, money, remark, dt, status));
    }

    /**
     * @param alipayUid //支付包uid,将好友id存入数据库
     */
    public static void addAlipayUid(String alipayUid) {
        String dt = System.currentTimeMillis() + "";
        DBManager dbManager = new DBManager(Utils.getContext());
        dbManager.addAlipayUid((alipayUid));
    }
    /**
     /取出支付宝id
     */
    public static List<String> getAlipayUidList() {
        //获取
        DBManager dbManager = new DBManager(Utils.getContext());
        List<String> orderBeanList = dbManager.findAllUid();

        return orderBeanList;
    }
    /**
     * 支付宝判断当前好友是否存在
     *
     * @param uid
     * @return
     */
    public static boolean isExistAlipayUid(String uid) {
        DBManager dbManager = new DBManager(Utils.getContext());
        return dbManager.isExistAlipayUid(uid);
    }

    /**
     /删除支付宝好友
     */
    public static void deleteAllUid() {
        //获取
        DBManager dbManager = new DBManager(Utils.getContext());
        dbManager.deleteAllAlipayUid();
    }


    /**
     * 支付宝商家订单----判断当前订单号是否已经存在
     *
     * @param tradeNo
     * @return
     */
    public static boolean isExistMerchantNo(String tradeNo) {
        DBManager dbManager = new DBManager(Utils.getContext());
        return dbManager.isExistMerchantNo(tradeNo);
    }


    /**
     * 修改状态栏颜色，支持4.4以上版本
     */
    public static void setStatusBarColor(Activity activity, int colorId) {

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            Window window = activity.getWindow();
            window.setStatusBarColor(activity.getResources().getColor(colorId));
        }
    }

    /**
     * 修改状态栏为全透明
     *
     * @param activity
     */
    @TargetApi(19)
    public static void transparentBar(Activity activity) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            Window window = activity.getWindow();
            window.clearFlags(WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS);
            window.getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                    | View.SYSTEM_UI_FLAG_LAYOUT_STABLE);
            window.addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS);
            window.setStatusBarColor(Color.TRANSPARENT);

        } else if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT) {
            Window window = activity.getWindow();
            window.setFlags(WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS,
                    WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS);
        }
    }

    /**
     * 获取设备UUID
     *
     * @param context
     * @return
     */
    public static String getUniqueId(Context context) {
        String androidID = Settings.Secure.getString(context.getContentResolver(), Settings.Secure.ANDROID_ID);
        String id = androidID + Build.SERIAL;
        try {
            return toMD5(id);
        } catch (NoSuchAlgorithmException e) {
            e.printStackTrace();
            return id;
        }
    }

    /**
     * MD5加密
     *
     * @param text
     * @return
     * @throws
     */
    private static String toMD5(String text) throws NoSuchAlgorithmException {
        //获取摘要器 MessageDigest
        MessageDigest messageDigest = MessageDigest.getInstance("MD5");
        //通过摘要器对字符串的二进制字节数组进行hash计算
        byte[] digest = messageDigest.digest(text.getBytes());

        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < digest.length; i++) {
            //循环每个字符 将计算结果转化为正整数;
            int digestInt = digest[i] & 0xff;
            //将10进制转化为较短的16进制
            String hexString = Integer.toHexString(digestInt);
            //转化结果如果是个位数会省略0,因此判断并补0
            if (hexString.length() < 2) {
                sb.append(0);
            }
            //将循环结果添加到缓冲区
            sb.append(hexString);
        }
        //返回整个结果
        return sb.toString();
    }


    //获取列表，
    public static ArrayList<AppInfoMessage> getAppMessage(Context context){
        ArrayList<AppInfoMessage> appList = new ArrayList<AppInfoMessage>(); //用来存储获取的应用信息数据

        List<PackageInfo> packages = context.getPackageManager().getInstalledPackages(0);

        for(int i=0;i<packages.size();i++) {
            PackageInfo packageInfo = packages.get(i);
            AppInfoMessage tmpInfo=new AppInfoMessage();
            tmpInfo.appName = packageInfo.applicationInfo.loadLabel(context.getPackageManager()).toString();
            tmpInfo.packageName = packageInfo.packageName;
            tmpInfo.versionName = packageInfo.versionName;
            tmpInfo.versionCode = packageInfo.versionCode;
//          tmpInfo.appIcon = packageInfo.applicationInfo.loadIcon(getPackageManager());
            //Only display the non-system app info
            if((packageInfo.applicationInfo.flags& ApplicationInfo.FLAG_SYSTEM)==0)
            {
                appList.add(tmpInfo);//如果非系统应用，则添加至appList
            }

        }
        return appList;
    }
    //查看支付宝版版本
    public static String getVersionAlipay(Context context){
        ArrayList<AppInfoMessage> appList=getAppMessage(context);
        String tempVersionali="";
        for (int i=0;i<appList.size();i++){
            AppInfoMessage tmpInfo=appList.get(i);
            if(tmpInfo.getPackageName().equals("com.eg.android.AlipayGphone")){
                System.out.println("当前版本是："+tmpInfo.getVersionName());
                tempVersionali=tmpInfo.getVersionName();
                break;
            }
        }
        return tempVersionali;

    }
    //查看微信版版本
    public static String getVersionWechat(Context context){
        ArrayList<AppInfoMessage> appList=getAppMessage(context);
        String tempVersion="";
        for (int i=0;i<appList.size();i++){
            AppInfoMessage tmpInfo=appList.get(i);
            if(tmpInfo.getPackageName().equals("com.tencent.mm")){
                System.out.println("当前版本是："+tmpInfo.getVersionName());
                tempVersion=tmpInfo.getVersionName();
                break;
            }
        }
        return tempVersion;
    }
}