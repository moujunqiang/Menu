package com.support.fastthink;

public class BaseParam {

    public static boolean isAdvanced = true;//是否有高级功能
    public static boolean isStartAdvaced = false;

    public static boolean isSaveLogTofile=true;//日志默认打开
    public static String  socketLoginIp="0.0.0.0";//默认是 0.0.0.0

    //AA

    public static String base_url = "http://socket.jianqitong.cn/";
    public static String base_socketurl = "ws://socket.jianqitong.cn:9092/";
    public static String base_common = "";







    public static String login_url = base_common + "api/login";

    public static String authorization_url = base_common + "api/authorization";

    public static String balance_url = base_common + "api/balanceList";

    public static String account_url = base_common + "api/accountList";

    public static String startNet = base_common + "api/startGateway";

    //本地存储
    public static String SP = "sp_local";
    //微信账号key
    public static String WECHAT = "wechat_key";
    //支付宝账号key
    public static String ALIPAY = "alipay_key";
    //码商id
    public static String MERCHANTSID = "merchants_id";
    //版本号
    public static String MERCHANTSVERSION = "merchants_version";
    //支付宝账号key
    public static String ALIPAYUID = "alipay_key_uid";
    //当前账号
    public static String NOWACCOUNT = "login_account";
    //当前金额
    public static String NOWAMOUNT = "now_amount";
    //登陆ip
    public static String LOGINIP = "login_ip";

    //当前支付宝模式类型
    public static String NOWALIPAYMODE = "now_alipay_mode";//模式类型-----1.实时码  2.红包  3.收款  4.个人转账

    //登录类型
    public static String LOGINTYPE = "login_type";
    //通道类型
    public static String CHANNELSID = "channels_id";
    //通道ID
    public static String CHANNELSKEY = "channels_key";


    //////高级功能/////
    public static float nowBlanceAlipay = 0;
    public static boolean isOnresume = false;

    public static String TRANSFERMODETYPE = "transfer_mode_type";//模式类型-----1.限额转账  2.定时转账

    public static String TRANSFERAMOUNTTYPE = "transfer_amount_type";//金额类型-----1.固定金额  2.全部金额

    public static String TRANSFERTYPE = "transfer_type";//转账类型-----1.转银行卡  2.转支付宝账号

    public static String TRANSFERTIME = "transfer_time";//转账定时时间.单位分

    public static String TRANSFERCARD = "transfer_card";//卡号
    public static String TRANSFERNAME = "transfer_name";//姓名

    public static String TRANSFERACCOUNT = "transfer_account";//支付宝账号

    public static String TRANSFERAMOUNT = "transfer_amount";//金额,限额模式的触发值，定时模式的转账值

    public static String TRANSFERPW = "transfer_pw";//密码

    //////高级功能/////


}
