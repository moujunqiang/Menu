package com.support.fastthink.entity;

import java.io.Serializable;

public class OrderBean implements Serializable {

    private String tradeno;//订单号
    private int type;//类型1、支付宝(个人) 2、支付宝(商家) 3.微信
    private String money;//金额
    private String remark;//当前余额
    private String dt;//时间戳
    private int status;//状态


    public OrderBean() {
        super();
    }

    public OrderBean(String tradeno, int type, String money, String remark, String dt, int status) {
        super();
        this.tradeno = tradeno;
        this.type = type;
        this.money = money;
        this.remark = remark;
        this.dt = dt;
        this.status = status;
    }

    public String getTradeno() {
        return tradeno;
    }

    public void setTradeno(String tradeno) {
        this.tradeno = tradeno;
    }

    public int getType() {
        return type;
    }

    public void setType(int type) {
        this.type = type;
    }

    public String getMoney() {
        return money;
    }

    public void setMoney(String money) {
        this.money = money;
    }

    public String getRemark() {
        return remark;
    }

    public void setRemark(String remark) {
        this.remark = remark;
    }

    public String getDt() {
        return dt;
    }

    public void setDt(String dt) {
        this.dt = dt;
    }

    public int getStatus() {
        return status;
    }

    public void setStatus(int status) {
        this.status = status;
    }
}
