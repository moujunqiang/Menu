package com.support.fastthink.utils;

import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

import com.support.fastthink.entity.OrderBean;

import java.util.ArrayList;

public class DBManager {
    private SQLiteDatabase db;
    private DBHelper helper;

    public DBManager(Context context) {
        helper = new DBHelper(context);
        db = helper.getWritableDatabase();
    }


    public void addOrder(OrderBean ordereBean) {
        db.beginTransaction();// 开始事务
        try {
            db.execSQL("INSERT INTO payorder VALUES(null,?,?,?,?,?,?)", new Object[]{ordereBean.getTradeno(), ordereBean.getType(), ordereBean.getMoney(), ordereBean.getRemark(), ordereBean.getDt(), ordereBean.getStatus()});
            db.setTransactionSuccessful();// 事务成功
        } finally {
            db.endTransaction();// 结束事务
        }
    }


    public boolean isExistMerchantNo(String tradeNo) {
        boolean isExist = false;
        String sql = "SELECT * FROM payorder WHERE tradeno='" + tradeNo + "' and type='2'";
        Cursor c = ExecSQLForCursor(sql);
        if (c.getCount() > 0) {
            isExist = true;
        }
        c.close();
        return isExist;
    }

    public void deleteAll() {
        db.beginTransaction();// 开始事务
        try {
            db.execSQL("delete from payorder", new Object[]{});
            db.setTransactionSuccessful();// 事务成功
        } finally {
            db.endTransaction();// 结束事务
        }
    }

    public ArrayList<OrderBean> findAllOrders() {
        String sql = "SELECT * FROM payorder";
        ArrayList<OrderBean> list = new ArrayList<>();
        Cursor c = ExecSQLForCursor(sql);
        while (c.moveToNext()) {
            OrderBean info = new OrderBean();
            info.setTradeno(c.getString(c.getColumnIndex("tradeno")));
            info.setType(c.getInt(c.getColumnIndex("type")));
            info.setMoney(c.getString(c.getColumnIndex("money")));
            info.setRemark(c.getString(c.getColumnIndex("remark")));
            info.setDt(c.getString(c.getColumnIndex("dt")));
            info.setStatus(c.getInt(c.getColumnIndex("status")));
            list.add(info);
        }
        c.close();
        return list;
    }

    /**
     * 执行SQL，返回一个游标
     *
     * @param sql
     * @return
     */
    private Cursor ExecSQLForCursor(String sql) {
        Cursor c = db.rawQuery(sql, null);
        return c;
    }



    public void addAlipayUid(String fienduid) {
        db.beginTransaction();// 开始事务
        try {
            db.execSQL("INSERT INTO alipayfriend VALUES(null,?)", new Object[]{fienduid});
            db.setTransactionSuccessful();// 事务成功
        } finally {
            db.endTransaction();// 结束事务
        }
    }
    public boolean isExistAlipayUid(String uid) {
        boolean isExist = false;
        String sql = "SELECT * FROM alipayfriend WHERE frienduid='" + uid + "'";
        Cursor c = ExecSQLForCursor(sql);
        if (c.getCount() > 0) {
            isExist = true;
        }
        c.close();
        return isExist;
    }
    public void deleteAllAlipayUid() {
        db.beginTransaction();// 开始事务
        try {
            db.execSQL("delete from alipayfriend", new Object[]{});
            db.setTransactionSuccessful();// 事务成功
        } finally {
            db.endTransaction();// 结束事务
        }
    }

    public ArrayList<String> findAllUid() {
        String sql = "SELECT * FROM alipayfriend";
        ArrayList<String> list = new ArrayList<>();
        Cursor c = ExecSQLForCursor(sql);
        while (c.moveToNext()) {
            String tempUid= c.getString(c.getColumnIndex("frienduid"));

            list.add(tempUid);
        }
        c.close();
        return list;
    }
}
