package com.example.club.Database;

import com.example.club.Objects.User;

public interface LogInDatabase {
    public User getUser(String username);
}
