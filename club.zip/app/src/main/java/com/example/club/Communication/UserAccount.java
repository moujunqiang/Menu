package com.example.club.Communication;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.provider.MediaStore;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.example.club.Database.DatabaseHelper;
import com.example.club.R;

public class UserAccount extends AppCompatActivity {
    ///////
    private Button mBtnconfirm4,mBtnCancel4;
    private ImageView profile;      // Profile of user
    private Button logOut;
    private Bitmap head = null;
    private static final int PICK_IMAGE=100;

    private SharedPreferences sprfMain;
    private SharedPreferences.Editor editorMain;

    private DatabaseHelper db;

    @SuppressLint("CommitPrefEdits")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        sprfMain = getSharedPreferences("config",0);
        int type = sprfMain.getInt("type",0);
        String username = sprfMain.getString("username","");
        db = new DatabaseHelper(UserAccount.this);

        switch (type){
            case 1:
                Intent club = new Intent(UserAccount.this, ClubAccount.class);
                startActivity(club);
                finish();
                break;

            case 2:
                Intent admin = new Intent(UserAccount.this, AdminAccount.class);
                startActivity(admin);
                finish();
                break;

            default:
                setContentView(R.layout.activity_hp_me_user);

                TextView user_account_username=findViewById(R.id.user_username);
                user_account_username.setText(username);

                profile = findViewById(R.id.user_portrait);
                head = db.getImage(username);
                profile.setImageBitmap(head);

                //below
                mBtnCancel4=(Button)findViewById(R.id.radio_button_home);
                mBtnCancel4.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        Intent intent = new Intent(UserAccount.this, aHomePage.class);
                        startActivity(intent);

                    }
                });
                mBtnCancel4=(Button)findViewById(R.id.radio_button_discovery);
                mBtnCancel4.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        Intent intent = new Intent(UserAccount.this, activity.class);
                        startActivity(intent);

                    }
                });
                mBtnCancel4=(Button)findViewById(R.id.radio_button_attention);
                mBtnCancel4.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        Intent intent = new Intent(UserAccount.this, messageList.class);
                        startActivity(intent);

                    }
                });


                // return to lohin
                logOut = findViewById(R.id.user_me_logout);
                logOut.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        resetSprfMain();
                        Intent intent = new Intent(UserAccount.this, LogIn.class);
                        startActivity(intent);
                        UserAccount.this.finish();
                    }
                });
                break;
        }


    }

    public void resetSprfMain(){
        sprfMain= getSharedPreferences("config",0);
        editorMain=sprfMain.edit();
        editorMain.clear();
        editorMain.commit();
    }

}