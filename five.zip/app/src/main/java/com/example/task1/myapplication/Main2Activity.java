package com.example.task1.myapplication;
import android.content.Intent;
import android.content.res.AssetFileDescriptor;
import android.content.res.AssetManager;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.io.IOException;

public class Main2Activity extends AppCompatActivity {


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        playbgmRing();
        //将布局好的登录界面activity_main2赋给Main2Activity
        setContentView(R.layout.activity_main2);
        Button logIn=(Button)findViewById(R.id.login);
        logIn.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                //获取用户名输入框这个控件
                EditText editUsername=(EditText)findViewById(R.id.userID);
                //将用户向输入框输入的用户名提取出来保存于nameInLogin
                String nameInLogin=editUsername.getText().toString();
                //定义一个页面跳转的意图
                Intent intent=new Intent(Main2Activity.this, MainActivity.class);
                //并向游戏页面传递用户名nameInLogin
                intent.putExtra("editUsername",nameInLogin);
                //获取密码输入框这个控件
                EditText editPassword=(EditText)findViewById(R.id.password);
                //将用户向输入框输入的密码提取出来保存于passwordInLogin
                String passwordInLogin=editPassword.getText().toString();
                //并向游戏页面传递密码passwordInLogin
                intent.putExtra("editPassword",passwordInLogin);
                //如果用户输入的用户名和密码与string.xml中保存的用户名和密码一致，则登录成功，跳转页面
                if(nameInLogin.equals(getResources().getString(R.string.OldUserName))&&
                        passwordInLogin.equals(getResources().getString(R.string.OldPassword))){
                    startActivity(intent);//跳转到游戏页面
                }
                //若用户名与密码不匹配，打印提示框提醒
                else{
                    Toast.makeText(Main2Activity.this,"账号或密码错误", Toast.LENGTH_SHORT).show();
                }


            }
        });
    }
    public AssetManager assetManager;
    public MediaPlayer playbgmRing() {
        MediaPlayer mediaPlayer = null;
        try {
            mediaPlayer = new MediaPlayer();
            assetManager = getAssets();
            AssetFileDescriptor fileDescriptor = assetManager.openFd("backgroundMusic.mp3");
            mediaPlayer.setDataSource(fileDescriptor.getFileDescriptor(),fileDescriptor.getStartOffset(),
                    fileDescriptor.getStartOffset());
            mediaPlayer.prepare();
            mediaPlayer.start();
            mediaPlayer.setLooping(true);

        } catch (IOException e) {
            e.printStackTrace();
        }
        return mediaPlayer;
    }


}
